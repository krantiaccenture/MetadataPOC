# RDF Metadata Graph

## 🚀 Overview

This project is an educational tool for learning about RDF, SPARQL, and graph-based metadata management. It provides a web-based, interactive interface for visualizing and querying a business metadata graph. The application is built with a modern client-server architecture, featuring a FastAPI backend and a Next.js frontend.

The core functionality includes:
-   **Excel to RDF Pipeline**: A configurable system for importing business metadata from Excel sheets into an RDF graph.
-   **Interactive Graph Visualization**: A dynamic, force-directed graph visualization of the RDF data.
-   **Node Filtering**: The ability to filter the graph display based on the type of node.
-   **Agentic Search**: A natural language query interface that uses an AI agent (powered by LangChain) to answer questions about the graph.

## 🏗️ Architecture

The application is divided into two main parts: a Python backend and a TypeScript frontend.

```mermaid
graph TD
    subgraph "Browser"
        A[Next.js Frontend]
    end

    subgraph "Server"
        B[FastAPI Backend]
        C[Triple Store (rdflib)]
        D[Data Source (Excel/TTL)]
        E[Agentic Search (LangChain)]
    end

    A -- "HTTP API Calls" --> B
    B -- "Serves Graph & Agent Responses" --> A
    B -- "Loads/Queries Data" --> C
    B -- "Processes Queries" --> E
    C -- "Imports/Caches Data From" --> D

    style A fill:#D6EAF8,stroke:#3498DB
    style B fill:#D5F5E3,stroke:#2ECC71
    style E fill:#F9E79F,stroke:#F1C40F
```

### **Backend (`/backend`)**

-   **Framework**: FastAPI
-   **Core Logic**: Manages the RDF data using `rdflib`, handles the Excel import process, and provides API endpoints for the frontend.
-   **Agentic Search**: Integrates with `LangChain` to provide natural language querying capabilities.
-   **State Management**: A singleton `state_manager` holds the graph in memory for fast access.

### **Frontend (`/frontend`)**

-   **Framework**: Next.js with React & TypeScript
-   **UI Components**: Built with `shadcn/ui`.
-   **Graph Visualization**: Uses `react-force-graph-2d` to render the interactive graph.
-   **State Management**: `Zustand` is used for simple, effective client-side state management.

## 🛠️ Setup and Running the Application

### **Prerequisites**

-   Python 3.10+
-   Node.js and npm
-   An OpenAI API key

### **1. Backend Setup**

1.  **Create `.env` file**: In the project root, create a file named `.env` and add your OpenAI API key:
    ```
    OPENAI_API_KEY="your-api-key-here"
    ```

2.  **Install Python Dependencies**: From the project root, create a virtual environment and install the required packages.
    ```powershell
    # Create and activate a virtual environment
    python -m venv .venv
    .\.venv\Scripts\Activate.ps1

    # Install dependencies
    pip install -r requirements.txt
    ```

3.  **Run the Backend Server**: Use the provided PowerShell script to start the FastAPI server.
    ```powershell
    .\run_api.ps1
    ```
    The backend will be running at `http://127.0.0.1:8000`.

### **2. Frontend Setup**

1.  **Navigate to Frontend Directory**: Open a new terminal and navigate to the `frontend` directory.
    ```powershell
    cd frontend
    ```

2.  **Install Node Dependencies**:
    ```powershell
    npm install
    ```

3.  **Add UI Components**: The project uses `shadcn/ui`. If you get any "module not found" errors for UI components, you may need to add them.
    ```powershell
    # Example for adding button and textarea
    npx shadcn-ui@latest add button
    npx shadcn-ui@latest add textarea
    ```

4.  **Run the Frontend Development Server**:
    ```powershell
    npm run dev
    ```
    The frontend will be running at `http://localhost:3000`. You can now open this URL in your browser to use the application.

