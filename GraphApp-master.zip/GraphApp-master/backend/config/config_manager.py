"""
Configuration Manager for RDF Metadata Graph

Provides hierarchical configuration management with dot notation access.
Implements the proven config pattern from architect methodology.
"""

import sys
from pathlib import Path

# Add project root to path for imports
# This is crucial for making the module runnable as a script
project_root = Path(__file__).resolve().parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

import yaml
from typing import Any, Dict, Optional

# Use the centralized logger factory
from backend.utils.logger_factory import get_component_logger

# Initialize a logger for this component
logger = get_component_logger('config_manager')

class ConfigDict(dict):
    """Enhanced dictionary with dot notation access and nested path support"""
    
    def __init__(self, data: dict = None):
        super().__init__()
        if data:
            self._deep_update(data)
    
    def __getattr__(self, key: str) -> Any:
        """Enable dot notation access: config.gui.window.width"""
        try:
            return self[key]
        except KeyError:
            raise AttributeError(f"'{self.__class__.__name__}' has no attribute '{key}'")
    
    def __setattr__(self, key: str, value: Any) -> None:
        """Enable dot notation assignment"""
        self[key] = value
    
    def _deep_update(self, data: dict) -> None:
        """Recursively convert nested dicts to ConfigDict instances"""
        for key, value in data.items():
            if isinstance(value, dict):
                self[key] = ConfigDict(value)
            else:
                self[key] = value
    
    def get_nested(self, path: str, default: Any = None) -> Any:
        """Get nested value using dot notation path"""
        keys = path.split('.')
        value = self
        try:
            for key in keys:
                value = value[key]
            return value
        except (KeyError, TypeError):
            return default

class ProjectConfigManager:
    """
    Manages project configuration files with hierarchical loading.
    Loads and merges all numbered YAML files from the config directory.
    """
    
    _instance: Optional['ProjectConfigManager'] = None
    _config: Optional[ConfigDict] = None
    _config_dir: Optional[Path] = None
    
    def __new__(cls, config_dir: Optional[Path] = None) -> 'ProjectConfigManager':
        """Singleton pattern implementation that is path-aware."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._config = None # Ensure config is fresh on first creation
            cls._instance._config_dir = config_dir
        
        # If a new path is provided, force a reload
        if config_dir and cls._instance._config_dir != config_dir:
            logger.info(f"Configuration directory changed to {config_dir}. Forcing reload.")
            cls._instance._config_dir = config_dir
            cls._instance._config = None # Reset config to trigger reload
            
        return cls._instance
    
    def __init__(self, config_dir: Optional[Path] = None):
        """Initialize configuration manager"""
        if self._config is None:
            self._load_configuration()
    
    def _load_configuration(self) -> None:
        """Load and merge all project configuration files"""
        config_dir = self._get_config_directory()
        
        # Find all numbered yaml files (e.g., 10_*.yaml, 15_*.yaml)
        config_files = sorted(config_dir.glob("[0-9][0-9]_*.yaml"))
        
        if not config_files:
            logger.error(f"No configuration files found in {config_dir}. Raising FileNotFoundError.")
            raise FileNotFoundError(f"No configuration files (e.g., 10_*.yaml) found in {config_dir}")
        
        merged_config = {}
        for config_file in config_files:
            try:
                with open(config_file, 'r', encoding='utf-8') as f:
                    file_config = yaml.safe_load(f)
                    if file_config:
                        merged_config = self._deep_merge(merged_config, file_config)
                        logger.debug(f"Successfully loaded and merged config from {config_file.name}")
            except Exception as e:
                logger.error(f"Error loading {config_file.name}: {e}", exc_info=True)
                raise
        
        self._config = ConfigDict(merged_config)
        logger.info(f"Configuration successfully loaded from {len(config_files)} files.")
    
    def _deep_merge(self, base: dict, override: dict) -> dict:
        """Deep merge two dictionaries, with override values taking precedence."""
        result = base.copy()
        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._deep_merge(result[key], value)
            else:
                result[key] = value
        return result
    
    def _get_config_directory(self) -> Path:
        """Get the configuration directory path."""
        if self._config_dir:
            return self._config_dir
        
        # Fallback to default behavior if no path is provided
        config_dir = project_root / "backend" / "config"
        if not config_dir.exists():
            logger.error(f"Config directory not found at expected path: {config_dir}")
            raise FileNotFoundError(f"Config directory not found: {config_dir}")
        return config_dir
    
    def get_project_config(self) -> ConfigDict:
        """Get the complete project configuration."""
        if self._config is None:
            self._load_configuration()
        return self._config
    
    def reload_configuration(self) -> None:
        """Force a reload of the configuration from files."""
        logger.info("Reloading configuration...")
        self._config = None
        self._load_configuration()

# --- Public API ---
def get_project_config(config_dir: Optional[Path] = None) -> ConfigDict:
    """
    Get the project configuration with dot notation access.
    
    Args:
        config_dir: Optional path to the configuration directory. If provided,
                    it initializes the config manager with that path.

    Usage:
        from config.config_manager import get_project_config
        config = get_project_config()
        # OR for specific path
        config = get_project_config(Path("/path/to/your/config"))
    """
    manager = ProjectConfigManager(config_dir)
    return manager.get_project_config()

# --- Independent Test Block ---
if __name__ == "__main__":
    
    def demonstrate_config_access():
        """Show different ways to access configuration using the logger."""
        logger.info("="*20 + " Config Manager Demonstration " + "="*20)
        
        try:
            # Demonstrate default path resolution
            logger.info("--- Testing with default path resolution ---")
            config = get_project_config()
            logger.info(f"Window width (default): {config.gui.window.width}")

            # Demonstrate explicit path resolution
            logger.info("\n--- Testing with explicit path ---")
            explicit_path = project_root / "backend" / "config"
            config_explicit = get_project_config(explicit_path)
            logger.info(f"Window width (explicit): {config_explicit.gui.window.width}")


        except Exception as e:
            logger.error(f"An error occurred during the demonstration: {e}", exc_info=True)
            logger.critical("Please ensure config files (e.g., '10_project_config.yaml') exist in the 'config/' directory.")
        
        logger.info("="*20 + " Demonstration Finished " + "="*20)
    
    demonstrate_config_access()
