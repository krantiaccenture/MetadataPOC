"""
Logger Factory for RDF Metadata Graph

Provides component-aware logging with configuration integration.
Implements the proven logging pattern from architect methodology.
"""

import logging
import logging.config
import yaml
from pathlib import Path
from typing import Optional, Dict, Any
import os


class LoggerFactory:
    """
    Factory for creating component-specific loggers with hierarchical configuration
    
    Integrates with configuration management and creates appropriate log directories.
    """
    
    _initialized: bool = False
    _config_loaded: bool = False
    
    @classmethod
    def _ensure_initialized(cls) -> None:
        """Ensure logging system is initialized"""
        if not cls._initialized:
            cls._setup_logging_system()
    
    @classmethod
    def _setup_logging_system(cls) -> None:
        """Initialize the logging system with configuration"""
        try:
            # Get logging configuration
            logging_config = cls._load_logging_config()
            
            # Ensure log directories exist
            cls._create_log_directories(logging_config)
            
            # Configure logging
            logging.config.dictConfig(logging_config)
            cls._config_loaded = True
            
            # Test that root logger works
            root_logger = logging.getLogger()
            root_logger.info("Logging system initialized successfully")
            
        except Exception as e:
            # Fallback to basic logging if config fails
            logging.basicConfig(
                level=logging.INFO,
                format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            logging.error(f"Failed to load logging config, using basic setup: {e}")
        
        cls._initialized = True
    
    @classmethod
    def _load_logging_config(cls) -> Dict[str, Any]:
        """Load logging configuration from YAML file"""
        config_dir = cls._get_config_directory()
        logging_files = sorted(config_dir.glob("2[0-9]_*logging*.yaml"))
        
        if not logging_files:
            raise FileNotFoundError("No logging config files (20-29) found")
        
        # Use the first logging config file found
        config_file = logging_files[0]
        
        with open(config_file, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        return config
    
    @classmethod
    def _create_log_directories(cls, config: Dict[str, Any]) -> None:
        """
        Create log directories from configuration using absolute paths.
        This method is modified to be robust against execution location.
        """
        project_root = Path(__file__).resolve().parent.parent.parent
        handlers = config.get('handlers', {})
        
        for handler_name, handler_config in handlers.items():
            if handler_config.get('class') == 'logging.FileHandler':
                log_file = handler_config.get('filename')
                if log_file:
                    # Create absolute path for the log file
                    absolute_log_path = project_root / log_file
                    absolute_log_path.parent.mkdir(parents=True, exist_ok=True)
                    # IMPORTANT: Update the config in-place to use the absolute path
                    handler_config['filename'] = str(absolute_log_path)
    
    @classmethod
    def _get_config_directory(cls) -> Path:
        """Get the configuration directory path"""
        # The config directory is now located inside the 'api' package
        project_root = Path(__file__).resolve().parent.parent.parent
        config_dir = project_root / "backend" / "config"
        
        if not config_dir.exists():
            raise FileNotFoundError(f"Config directory not found: {config_dir}")
        
        return config_dir
    
    @classmethod
    def get_component_logger(cls, component_name: str) -> logging.Logger:
        """
        Get a logger configured for a specific component
        
        Args:
            component_name: Name of the component (e.g., 'rdf_engine', 'gui.graph_canvas')
        
        Returns:
            Configured logger instance
        
        Usage:
            from src.utils.logger_factory import get_component_logger
            logger = get_component_logger('rdf_engine.triple_store')
        """
        cls._ensure_initialized()
        
        # Create logger with component-specific name
        logger = logging.getLogger(component_name)
        
        # Add component context if config was loaded successfully
        if cls._config_loaded:
            # The logger will inherit configuration from logging.yaml
            # based on the component hierarchy
            pass
        else:
            # Fallback configuration if main config failed
            logger.setLevel(logging.INFO)
        
        return logger


# Convenience function for easy import
def get_component_logger(component_name: str) -> logging.Logger:
    """
    Get a component-specific logger
    
    This is the main interface for getting loggers throughout the application.
    
    Usage:
        from src.utils.logger_factory import get_component_logger
        
        # In RDF engine modules
        logger = get_component_logger('rdf_engine.triple_store')
        
        # In GUI modules  
        logger = get_component_logger('gui.graph_canvas')
        
        # In model modules
        logger = get_component_logger('models.node_types')
    """
    return LoggerFactory.get_component_logger(component_name)


if __name__ == "__main__":
    """
    Dynamic and robust demonstration and testing for the LoggerFactory.
    This harness now reads the logging config to dynamically test all defined loggers.
    """
    
    # Add project root to path to allow direct script execution
    # This is necessary for the next import to work
    import sys
    project_root = Path(__file__).resolve().parent.parent.parent
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))

    def demonstrate_logger_creation():
        """Shows logger factory capabilities by testing all configured loggers."""
        print("=== Logger Factory Demonstration ===\n")
        
        try:
            # Manually load the config to find all loggers to test
            log_config = LoggerFactory._load_logging_config()
            configured_loggers = list(log_config.get('loggers', {}).keys())
            
            if not configured_loggers:
                print("No custom loggers found in configuration to test.")
                return

            print("1. Dynamically creating component loggers from config:")
            for logger_name in configured_loggers:
                logger = get_component_logger(logger_name)
                print(f"   ✓ Got logger: '{logger.name}'")
                logger.info(f"This is a test INFO message from the '{logger.name}' logger.")
                logger.debug(f"This is a test DEBUG message from the '{logger.name}' logger.")

            print("\n2. Log file locations:")
            logs_dir = project_root / "logs"
            if logs_dir.exists():
                log_files = list(logs_dir.glob("*.log"))
                if not log_files:
                    print("   - No log files found yet. They will be created by the handlers.")
                for log_file in log_files:
                    print(f"   📁 {log_file.name}")
            else:
                print("   - Logs directory does not exist yet.")

            print("\n3. Configuration status:")
            print(f"   - Initialized: {LoggerFactory._initialized}")
            print(f"   - Config loaded: {LoggerFactory._config_loaded}")
            print("\n=== Demonstration Finished ===\n")
            print("Please check the files in the 'logs' directory to verify the output.")

        except Exception as e:
            print(f"\n!!! An error occurred during the demonstration: {e}")
            import traceback
            traceback.print_exc()

    demonstrate_logger_creation()
