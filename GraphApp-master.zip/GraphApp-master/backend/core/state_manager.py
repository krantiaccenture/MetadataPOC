"""
Global State Management for the RDF Metadata Graph API

This module is the single source of truth for the application's data. It initializes
and holds singleton instances of TripleStores for business and schema data,
populated at application startup.
"""
import sys
import json
from pathlib import Path
from collections import defaultdict
from rdflib import Graph, URIRef, RDF, RDFS, Literal

# Add project root to path
project_root = Path(__file__).resolve().parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from backend.rdf_engine.triple_store import TripleStore
from backend.config.config_manager import get_project_config, ConfigDict
from backend.utils.logger_factory import get_component_logger

# --- Global State ---
BUSINESS_TRIPLE_STORE: TripleStore | None = None
SCHEMA_TRIPLE_STORE: TripleStore | None = None
logger = get_component_logger("api.state_manager")

def initialize_triple_store(config: ConfigDict):
    """
    Initializes and loads the business and schema triple stores.
    """
    global BUSINESS_TRIPLE_STORE, SCHEMA_TRIPLE_STORE
    logger.info("Initializing business and schema TripleStores...")

    BUSINESS_TRIPLE_STORE = TripleStore()
    SCHEMA_TRIPLE_STORE = TripleStore()

    data_dir = Path(config.paths.data_dir)
    imported_graph_file = data_dir / "imported_graph.ttl"
    namespaces_file = data_dir / config.paths.namespaces_file

    # Load Business Graph
    if imported_graph_file.exists():
        logger.info(f"Loading business graph from {imported_graph_file}...")
        BUSINESS_TRIPLE_STORE.load_graph(str(imported_graph_file))
    else:
        logger.warning(f"Business graph file not found at {imported_graph_file}. Running Excel import...")
        from backend.rdf_engine.excel_import import ExcelImporter
        importer = ExcelImporter(triple_store=BUSINESS_TRIPLE_STORE)
        excel_file = Path(config.excel_import.file_settings.input_file)
        if excel_file.exists():
            importer.import_excel_to_rdf(str(excel_file))
            BUSINESS_TRIPLE_STORE.save_graph(str(imported_graph_file))
        else:
            logger.error(f"Could not run import. Excel file not found: {excel_file}")

    # Load Schema Graph
    if namespaces_file.exists():
        logger.info(f"Loading schema graph from {namespaces_file}...")
        SCHEMA_TRIPLE_STORE.load_graph(str(namespaces_file))
    else:
        logger.error(f"Schema file (namespaces.ttl) not found at {namespaces_file}")

    logger.info("TripleStores initialized successfully.")

def _transform_graph_to_json(main_store: TripleStore, schema_store: TripleStore):
    if not main_store or not schema_store:
        logger.error("One or both TripleStores are not initialized.")
        return {"nodes": [], "links": []}

    nodes = {}
    links = []
    base_ns = main_store.base_namespace
    
    real_entity_uris = {str(s) for s, _, _ in main_store.graph if str(s).startswith(base_ns)}

    for s_uri in real_entity_uris:
        nodes[s_uri] = {"id": s_uri, "attributes": defaultdict(list), "nodeType": "Unknown"}
        node_type = "Unknown"
        
        for _, p, o in main_store.graph.triples((URIRef(s_uri), None, None)):
            if isinstance(o, Literal):
                predicate_label = schema_store.get_label(p)
                nodes[s_uri]["attributes"][predicate_label].append(str(o))
            
            if p == RDF.type and isinstance(o, URIRef):
                node_type = schema_store.get_label(o) or main_store.get_label(o)
        
        nodes[s_uri]["nodeType"] = node_type
        nodes[s_uri]["attributes"]["nodeType"].append(node_type)


    for s_uri in real_entity_uris:
        s = URIRef(s_uri)
        for _, p, o in main_store.graph.triples((s, None, None)):
            if isinstance(o, URIRef) and p != RDF.type and str(o) in real_entity_uris:
                s_str, o_str = str(s), str(o)
                predicate_label = schema_store.get_label(p)
                
                object_label_list = nodes[o_str].get("attributes", {}).get("label", [])
                object_label = object_label_list[0] if object_label_list else o_str.split('/')[-1]
                
                nodes[s_str]["attributes"][predicate_label].append(object_label)
                links.append({"source": s_str, "target": o_str, "label": predicate_label})

    for node_id, node_data in nodes.items():
        attributes = node_data["attributes"]
        
        label_values = attributes.get("label", [])
        node_data["label"] = label_values[0] if label_values else node_id.split('/')[-1]

        for key, value in attributes.items():
            if key in ["label", "comment", "nodeType"] and len(value) == 1:
                attributes[key] = value[0]

    return {"nodes": list(nodes.values()), "links": links}

def get_business_graph_json():
    logger.info("Generating business graph JSON...")
    return _transform_graph_to_json(BUSINESS_TRIPLE_STORE, SCHEMA_TRIPLE_STORE)

def get_schema_graph_json():
    logger.info("Generating schema graph JSON...")
    return _transform_graph_to_json(SCHEMA_TRIPLE_STORE, SCHEMA_TRIPLE_STORE)

def get_full_graph_json():
    logger.info("Generating full graph JSON...")
    full_store = TripleStore()
    full_store.graph += BUSINESS_TRIPLE_STORE.graph
    full_store.graph += SCHEMA_TRIPLE_STORE.graph
    return _transform_graph_to_json(full_store, SCHEMA_TRIPLE_STORE)

def refresh_from_excel():
    logger.info("Starting data refresh from Excel source...")
    config = get_project_config()
    initialize_triple_store(config)
    return {"status": "success", "message": "Data refreshed from Excel and stores re-initialized."}

if __name__ == "__main__":
    logger.info("="*30 + " State Manager Test Harness " + "="*30)
    try:
        test_config = get_project_config()
        initialize_triple_store(test_config)
        
        logger.info("\n--- Generating Business Graph JSON ---")
        business_data = get_business_graph_json()
        logger.info(f"Generated business JSON for {len(business_data['nodes'])} nodes and {len(business_data['links'])} links.")
        
        log_dir = project_root / "logs"
        log_dir.mkdir(exist_ok=True)
        with open(log_dir / "state_manager_graph_output.json", "w", encoding="utf-8") as f:
            json.dump(business_data, f, indent=2)
        logger.info("Wrote business graph to state_manager_graph_output.json")

        logger.info("\n--- Generating Schema Graph JSON ---")
        schema_data = get_schema_graph_json()
        logger.info(f"Generated schema JSON for {len(schema_data['nodes'])} nodes and {len(schema_data['links'])} links.")
        with open(log_dir / "state_manager_schema_output.json", "w", encoding="utf-8") as f:
            json.dump(schema_data, f, indent=2)
        logger.info("Wrote schema graph to state_manager_schema_output.json")

        logger.info("\n" + "="*30 + " Test COMPLETED " + "="*30)
    except Exception as e:
        logger.error(f"Test harness failed: {e}", exc_info=True)
