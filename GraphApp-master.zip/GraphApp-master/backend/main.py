"""
Main FastAPI application for the RDF Metadata Graph API.

This file serves as the entry point for the API server, managing the application
lifecycle and defining the API endpoints.
"""

import sys
from pathlib import Path
from contextlib import asynccontextmanager

# Add project root to path to allow direct script execution and consistent imports
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from backend.core import state_manager
from backend.config.config_manager import get_project_config
from backend.utils.logger_factory import get_component_logger
from backend.agents.agentic_search import MetadataAgent

logger = get_component_logger("api")

# Load configuration at the top level
config = get_project_config()
agent = MetadataAgent()

class AgentQuery(BaseModel):
    prompt: str

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifecycle manager.
    Handles resource initialization on startup and cleanup on shutdown.
    """
    logger.info("Application startup: Initializing resources...")
    state_manager.initialize_triple_store(config)
    logger.info("Resources initialized.")
    yield
    logger.info("Application shutdown: Releasing resources...")
    # Future cleanup logic can go here

# Initialize the FastAPI application
app = FastAPI(
    title="RDF Metadata Graph API",
    description="An API for interacting with the business metadata graph.",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware to the application instance *before* it starts.
# This is the correct place to configure middleware.
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.api.cors.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/", tags=["Root"])
async def read_root():
    """
    Root endpoint for the API.
    Provides a simple status message to confirm the API is running.
    """
    return {"status": "success", "message": "Welcome to the RDF Metadata Graph API"}

@app.get("/graph", tags=["Graph Data"])
async def get_graph():
    """
    Retrieves the entire graph data as a nodes/links JSON object.
    
    This endpoint accesses the pre-loaded data from the singleton TripleStore.
    """
    if not state_manager.BUSINESS_TRIPLE_STORE:
        raise HTTPException(status_code=500, detail="Graph has not been initialized.")
    return state_manager.get_business_graph_json()

@app.post("/agent-query", tags=["Agent"])
async def agent_query(query: AgentQuery):
    """
    Submits a natural language query to the Metadata Agent.
    """
    if not state_manager.BUSINESS_TRIPLE_STORE:
        raise HTTPException(status_code=500, detail="Graph has not been initialized.")
    
    schema_summary = state_manager.BUSINESS_TRIPLE_STORE.get_schema_summary()
    result = agent.run(query.prompt, schema_summary)

    if result.get("error"):
        raise HTTPException(status_code=500, detail=result["error"])
    
    return {"response": result.get("response")}

@app.post("/refresh-from-excel", tags=["Graph Data"])
async def refresh_graph_from_excel():
    """
    Forces a re-import of data from the source Excel file.

    This operation deletes the cache, clears the in-memory graph, re-runs the
    Excel import, and saves the new graph to the cache. It is a long-running
    operation and should be used with caution.
    """
    if not state_manager.BUSINESS_TRIPLE_STORE:
        raise HTTPException(status_code=500, detail="Graph has not been initialized.")
    return state_manager.refresh_from_excel()
