"""
RDF Triple Store - Core RDF Operations

This module provides the foundation for RDF triple management using rdflib.
It handles the creation, querying, and manipulation of RDF graphs for business metadata.
"""

import sys
from pathlib import Path

# Add project root to path for imports
project_root = Path(__file__).parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from rdflib import Graph, Namespace, URIRef, Literal
from rdflib.namespace import RDF, RDFS, SKOS
from typing import Union, List, Dict, Any, Optional

from backend.utils.logger_factory import get_component_logger
from backend.config.config_manager import get_project_config

logger = get_component_logger('rdf_engine.triple_store')

class TripleStore:
    """
    Core RDF Triple Store for business metadata management.
    Encapsulates rdflib Graph operations.
    """
    
    def __init__(self):
        self.config = get_project_config()
        self.graph = Graph()
        
        rdf_config = self.config.excel_import.rdf_settings
        self.base_namespace = rdf_config.base_namespace
        self.namespace_prefix = rdf_config.namespace_prefix
        
        self.META = Namespace(self.base_namespace)
        
        self.graph.bind(self.namespace_prefix, self.META)
        self.graph.bind("rdf", RDF)
        self.graph.bind("rdfs", RDFS)
        
        logger.info(f"Initialized triple store with namespace: {self.base_namespace}")
    
    def get_namespace(self) -> Namespace:
        return self.META
    
    def create_triple(self, subject: str, predicate: str, obj: Union[str, int, float]) -> bool:
        """Creates a single RDF triple in the graph."""
        try:
            subj_uri = self.META[self._normalize_uri(subject)]
            pred_uri = self.META[self._normalize_uri(predicate)]
            
            if isinstance(obj, str) and not obj.startswith('http'):
                obj_uri = self.META[self._normalize_uri(obj)]
            elif isinstance(obj, (int, float)):
                obj_uri = Literal(obj)
            else:
                obj_uri = Literal(obj) if not obj.startswith('http') else URIRef(obj)
            
            self.graph.add((subj_uri, pred_uri, obj_uri))
            logger.debug(f"Added triple: {subj_uri} {pred_uri} {obj_uri}")
            return True
        except Exception as e:
            logger.error(f"Failed to create triple: {subject} {predicate} {obj} - Error: {e}")
            return False
    
    def create_entity_with_type(self, entity_name: str, entity_type: str, label: str = None, description: str = None) -> bool:
        """Creates a business entity with its RDF type and optional properties."""
        try:
            entity_uri = self.META[self._normalize_uri(entity_name)]
            type_uri = self.META[entity_type]
            
            self.graph.add((entity_uri, RDF.type, type_uri))
            if label: self.graph.add((entity_uri, RDFS.label, Literal(label)))
            if description: self.graph.add((entity_uri, RDFS.comment, Literal(description)))
            
            logger.debug(f"Created entity: {entity_name} of type {entity_type}")
            return True
        except Exception as e:
            logger.error(f"Failed to create entity: {entity_name} - Error: {e}")
            return False
    
    def create_relationship(self, subject: str, relationship: str, obj: str) -> bool:
        """Creates a relationship between two business entities."""
        return self.create_triple(subject, relationship, obj)
    
    def execute_sparql(self, query: str) -> List[Dict[str, Any]]:
        """Executes a SPARQL query against the triple store."""
        try:
            results = self.graph.query(query)
            result_list = [{str(var): str(row[var]) if row[var] else None for var in results.vars} for row in results]
            logger.debug(f"SPARQL query returned {len(result_list)} results")
            return result_list
        except Exception as e:
            logger.error(f"SPARQL query failed: {query} - Error: {e}", exc_info=True)
            raise

    def clear_graph(self) -> bool:
        """Clears all triples from the graph."""
        try:
            self.graph.remove((None, None, None))
            logger.info("Graph cleared successfully")
            return True
        except Exception as e:
            logger.error(f"Failed to clear graph: {e}")
            return False

    def save_graph(self, filepath: str, format: str = 'turtle') -> bool:
        """Saves the current graph to a file."""
        try:
            self.graph.serialize(destination=filepath, format=format)
            logger.info(f"Graph successfully saved to {filepath}")
            return True
        except Exception as e:
            logger.error(f"Failed to save graph to {filepath}: {e}")
            return False

    def load_graph(self, filepath: str, format: str = 'turtle') -> bool:
        """Loads a graph from a file, adding it to the existing graph."""
        try:
            self.graph.parse(source=filepath, format=format)
            logger.info(f"Graph successfully loaded from {filepath}")
            return True
        except Exception as e:
            logger.error(f"Failed to load graph from {filepath}: {e}")
            return False
    
    def get_graph_size(self) -> int:
        """Gets the number of triples in the graph."""
        return len(self.graph)
    
    def _normalize_uri(self, name: str) -> str:
        """Normalizes a name for use in URIs."""
        if self.config.excel_import.rdf_settings.uri_normalization:
            normalized = name.replace(' ', '_').replace('-', '_')
            return ''.join(c for c in normalized if c.isalnum() or c == '_')
        return name
    
    def get_serialized_graph(self, format: str = 'turtle') -> str:
        """Gets the RDF graph as a serialized string."""
        try:
            return self.graph.serialize(format=format)
        except Exception as e:
            logger.error(f"Failed to serialize graph: {e}")
            return ""

    def get_label(self, uri_ref: URIRef) -> str:
        """Retrieves a human-readable label for a given URI."""
        if not isinstance(uri_ref, URIRef): return str(uri_ref)

        label_properties = [RDFS.label, SKOS.prefLabel]
        for prop in label_properties:
            label = self.graph.value(subject=uri_ref, predicate=prop)
            if label: return str(label)
        return str(uri_ref).split('/')[-1].split('#')[-1]

    def get_schema_summary(self) -> str:
        """Generates a string summary of the graph's schema."""
        summary = ["Namespaces:"]
        for prefix, namespace in self.graph.namespaces():
            summary.append(f"  {prefix}: {namespace}")

        summary.append("\nClasses (use these with 'a' or 'rdf:type'):")
        try:
            classes_query = "SELECT DISTINCT ?class WHERE { [] a ?class . FILTER(isIRI(?class)) }"
            results = self.graph.query(classes_query)
            for row in sorted(results):
                try:
                    summary.append(f"  {self.graph.namespace_manager.qname(row[0])} ({row[0]})")
                except:
                    summary.append(f"  {row[0]}")
        except Exception as e:
            summary.append(f"  Error querying classes: {e}")

        summary.append("\nProperties (use these to connect entities):")
        try:
            prop_query = "SELECT DISTINCT ?p WHERE { ?s ?p ?o . FILTER(isIRI(?p)) }"
            results = self.graph.query(prop_query)
            for row in sorted(results):
                if row[0] == RDF.type: continue
                try:
                    summary.append(f"  {self.graph.namespace_manager.qname(row[0])} ({row[0]})")
                except:
                    summary.append(f"  {row[0]}")
        except Exception as e:
            summary.append(f"  Error querying properties: {e}")
        return "\n".join(summary)


def main():
    """Demonstration of TripleStore functionality using the logger."""
    logger.info("="*20 + " TripleStore Component Test " + "="*20)
    
    try:
        logger.info("1. Initializing Triple Store...")
        store = TripleStore()
        ns = store.get_namespace()
        logger.info(f"   - Triple store initialized with namespace: {store.base_namespace}")
        logger.info(f"   - Graph size: {store.get_graph_size()} triples")
        
        logger.info("\n2. Creating Basic RDF Triples...")
        logger.info("   - Educational Note: Each business fact becomes a Subject-Predicate-Object triple.")
        
        entities_to_create = [
            ("SalesDomain", "DataDomain", "Sales", "Sales business area"),
            ("SalesTransactions", "SubDomain", "Transactions", "Sales transaction processing"),
            ("SalesHeader", "Entity", "Sales Transaction Header", "Main sales transaction record"),
        ]
        for name, type, label, desc in entities_to_create:
            store.create_entity_with_type(name, type, label, desc)
            logger.info(f"   - Created {type}: {name} ('{label}')")
        
        logger.info("\n3. Creating Business Relationships...")
        store.create_relationship("SalesDomain", "contains", "SalesTransactions")
        logger.info("   - Relationship: SalesDomain contains SalesTransactions")
        store.create_relationship("SalesTransactions", "includes", "SalesHeader")
        logger.info("   - Relationship: SalesTransactions includes SalesHeader")
        
        logger.info(f"\n   - Graph now contains {store.get_graph_size()} triples")
        
        logger.info("\n4. Testing SPARQL Queries...")
        
        query1 = "SELECT ?label WHERE { ?domain a meta:DataDomain ; rdfs:label ?label . }"
        results1 = store.execute_sparql(query1)
        logger.info("   - Query 1: Find all Data Domains")
        for result in results1: logger.info(f"     - Found domain: {result.get('label', 'N/A')}")
        
        query2 = "SELECT ?sub_label WHERE { meta:SalesDomain meta:contains ?sub . ?sub rdfs:label ?sub_label . }"
        results2 = store.execute_sparql(query2)
        logger.info("   - Query 2: Find subdomains of SalesDomain")
        for result in results2: logger.info(f"     - Found subdomain: {result.get('sub_label', 'N/A')}")

        logger.info("\n5. RDF Serialization Preview...")
        logger.info("   - Educational Note: Turtle format shows human-readable RDF.")
        turtle_output = store.get_serialized_graph('turtle').splitlines()[:5]
        for line in turtle_output: logger.info(f"     {line}")

        logger.info("\n6. Schema Summary Preview...")
        schema_summary = store.get_schema_summary().splitlines()[:7]
        for line in schema_summary: logger.info(f"     {line}")

        logger.info("\n" + "="*20 + " Test COMPLETED SUCCESSFULLY " + "="*20)
        
    except Exception as e:
        logger.error(f"Component test failed: {e}", exc_info=True)

if __name__ == "__main__":
    main()
