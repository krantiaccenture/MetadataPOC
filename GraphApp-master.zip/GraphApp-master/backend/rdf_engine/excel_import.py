"""
Excel Import Pipeline for RDF Metadata Graph
===========================================

This module provides configurable Excel-to-RDF data ingestion functionality.
All operations are driven by configuration settings from 15_excel_import.yaml.

Key Features:
- CONFIG-DRIVEN: No hardcoded column names or entity types
- Flexible column mapping through configuration
- Comprehensive data validation
- Replace strategy with backup support
- Educational RDF concept integration

RDF Concepts Explained:
- Excel rows become RDF triples (subject-predicate-object)
- Hierarchical relationships: Domain -> SubDomain -> Entity -> PhysicalTable
- Each cell value becomes either a subject or object in RDF
- Relationships between entities become predicates
"""

import sys
from pathlib import Path
import pandas as pd
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Any
import re
from rdflib import Graph, Namespace, Literal, URIRef, RDF, RDFS

# Add project root to path for imports
project_root = Path(__file__).parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# Import project modules
from backend.config.config_manager import get_project_config
from backend.utils.logger_factory import get_component_logger
from backend.rdf_engine.triple_store import TripleStore

# Initialize configuration and logger
config = get_project_config()
import_config = config.excel_import
logger = get_component_logger('rdf_engine.excel_import')

# Create namespace from configuration
META = Namespace(import_config.rdf_settings.base_namespace)


class ExcelImporter:
    """
    Handles Excel-to-RDF import pipeline with full configuration support.
    
    This class demonstrates how tabular data (Excel) can be transformed into
    graph data (RDF). Each row in Excel represents multiple RDF triples that
    express relationships between business metadata entities.
    """
    
    def __init__(self, triple_store: Optional[TripleStore] = None):
        """
        Initialize the Excel importer with configuration settings.
        
        Args:
            triple_store: Optional existing TripleStore instance to use
        """
        self.config = import_config
        self.triple_store = triple_store or TripleStore()
        
        # Get column names from configuration
        self.col_mappings = self.config.column_mappings
        self.validation_rules = self.config.validation_rules
        
        # Log initialization with config details
        logger.info(f"ExcelImporter initialized with column mappings: "
                   f"{self.col_mappings.domain_column}->SubDomain, "
                   f"{self.col_mappings.entity_column}->Entity")
    
    def read_excel_file(self, filepath: str) -> pd.DataFrame:
        """
        Read Excel file into DataFrame with configuration-driven settings.
        
        This is our first step in converting tabular data to RDF. The DataFrame
        represents a flat, table-based view that we'll transform into a graph.
        """
        filepath = Path(filepath)
        
        if not filepath.exists():
            error_msg = f"Excel file not found: {filepath}"
            logger.error(error_msg)
            raise FileNotFoundError(error_msg)
        
        supported_formats = self.config.file_settings.supported_formats
        if filepath.suffix.lower() not in supported_formats:
            error_msg = (f"Unsupported file format: {filepath.suffix}. "
                        f"Supported formats from config: {supported_formats}")
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        logger.info(f"Reading Excel file: {filepath}")
        try:
            if filepath.suffix.lower() == '.csv':
                df = pd.read_csv(
                    filepath,
                    encoding=self.config.file_settings.encoding,
                    skiprows=self.config.file_settings.skip_rows
                )
            else:
                df = pd.read_excel(
                    filepath,
                    sheet_name=self.config.file_settings.sheet_name,
                    skiprows=self.config.file_settings.skip_rows
                )
            
            logger.info(f"Successfully read {len(df)} rows from {filepath.name}")
            logger.debug(f"Columns found: {list(df.columns)}")
            
            return df
            
        except Exception as e:
            error_msg = f"Error reading Excel file: {str(e)}"
            logger.error(error_msg)
            raise
    
    def validate_excel_structure(self, df: pd.DataFrame) -> Dict[str, List[str]]:
        """
        Validate Excel structure matches configured column mappings.
        """
        validation_results = {'missing_columns': [], 'warnings': [], 'info': []}
        
        for config_key, excel_column in self.col_mappings.items():
            if excel_column not in df.columns:
                validation_results['missing_columns'].append(
                    f"Configuration key '{config_key}' expects column '{excel_column}' which is missing"
                )
        
        required_fields = self.validation_rules.required_fields
        for req_field in required_fields:
            if hasattr(self.col_mappings, req_field):
                excel_col = getattr(self.col_mappings, req_field)
                if excel_col not in df.columns:
                    validation_results['missing_columns'].append(
                        f"Required column '{excel_col}' (from {req_field}) is missing"
                    )
        
        if validation_results['missing_columns']:
            logger.error(f"Missing columns: {validation_results['missing_columns']}")
        else:
            logger.info(f"All required columns present. Found columns: {list(df.columns)}")
        
        return validation_results
    
    def validate_data_values(self, df: pd.DataFrame) -> Dict[str, List[str]]:
        """
        Validate data values according to configuration rules.
        """
        issues = {'errors': [], 'warnings': []}
        
        domain_col = self.col_mappings.domain_column
        subdomain_col = self.col_mappings.subdomain_column
        entity_col = self.col_mappings.entity_column
        table_col = self.col_mappings.table_column
        
        naming_pattern = re.compile(self.validation_rules.naming_convention)
        max_length = self.validation_rules.max_length
        
        for idx, row in df.iterrows():
            row_num = idx + 2
            
            if domain_col in df.columns and pd.isna(row[domain_col]):
                issues['errors'].append(f"Row {row_num}: Required field '{domain_col}' is empty")
            
            if entity_col in df.columns and pd.isna(row[entity_col]):
                issues['errors'].append(f"Row {row_num}: Required field '{entity_col}' is empty")
            
            for config_key, excel_col in self.col_mappings.items():
                if excel_col in df.columns and pd.notna(row[excel_col]):
                    value = str(row[excel_col])
                    if not naming_pattern.match(value):
                        issues['warnings'].append(
                            f"Row {row_num}: '{excel_col}' value '{value}' "
                            f"doesn't match pattern {self.validation_rules.naming_convention}"
                        )
                    if len(value) > max_length:
                        issues['warnings'].append(
                            f"Row {row_num}: '{excel_col}' value exceeds "
                            f"max length {max_length}"
                        )
            
            if not self.validation_rules.allow_empty_subdomain:
                if subdomain_col in df.columns and pd.isna(row[subdomain_col]):
                    issues['errors'].append(f"Row {row_num}: '{subdomain_col}' cannot be empty")
            
            if not self.validation_rules.allow_empty_table:
                if table_col in df.columns and pd.isna(row[table_col]):
                    issues['errors'].append(f"Row {row_num}: '{table_col}' cannot be empty")
        
        if self.validation_rules.check_duplicates:
            if entity_col in df.columns:
                duplicates = df[entity_col].dropna().duplicated()
                if duplicates.any():
                    dup_values = df[entity_col][duplicates].unique()
                    issues['warnings'].append(f"Duplicate values in '{entity_col}': {list(dup_values)}")
        
        logger.info(f"Data validation complete: {len(issues['errors'])} errors, {len(issues['warnings'])} warnings")
        return issues
    
    def normalize_uri_component(self, value: str) -> str:
        """
        Normalize a value for use in RDF URI.
        """
        if not self.config.rdf_settings.uri_normalization:
            return value
        
        normalized = value.replace(' ', '_')
        normalized = re.sub(r'[^a-zA-Z0-9_]', '', normalized)
        if normalized and normalized[0].isdigit():
            normalized = 'N' + normalized
        
        return normalized
    
    def parse_hierarchy(self, df: pd.DataFrame) -> Dict[str, Dict[str, Any]]:
        """
        Parse Excel data into hierarchical structure for RDF generation.
        """
        hierarchy = {}
        
        domain_col = self.col_mappings.domain_column
        subdomain_col = self.col_mappings.subdomain_column
        entity_col = self.col_mappings.entity_column
        table_col = self.col_mappings.table_column
        
        logger.info(f"Parsing hierarchy from columns: {domain_col} -> {subdomain_col} -> {entity_col} -> {table_col}")
        
        for _, row in df.iterrows():
            domain = row.get(domain_col)
            subdomain = row.get(subdomain_col)
            entity = row.get(entity_col)
            table = row.get(table_col)
            
            if pd.isna(domain): continue
            
            domain = str(domain).strip()
            if domain not in hierarchy:
                hierarchy[domain] = {'uri': self.normalize_uri_component(domain), 'label': domain, 'type': 'DataDomain', 'subdomains': {}}
            
            if pd.notna(subdomain):
                subdomain = str(subdomain).strip()
                if subdomain not in hierarchy[domain]['subdomains']:
                    hierarchy[domain]['subdomains'][subdomain] = {'uri': self.normalize_uri_component(subdomain), 'label': subdomain, 'type': 'SubDomain', 'entities': {}}
                subdomain_dict = hierarchy[domain]['subdomains'][subdomain]
            else:
                if self.validation_rules.allow_empty_subdomain:
                    default_subdomain = '_DirectEntities'
                    if default_subdomain not in hierarchy[domain]['subdomains']:
                        hierarchy[domain]['subdomains'][default_subdomain] = {'uri': 'DirectEntities', 'label': 'Direct Entities', 'type': 'SubDomain', 'entities': {}}
                    subdomain_dict = hierarchy[domain]['subdomains'][default_subdomain]
                else:
                    continue
            
            if pd.notna(entity):
                entity = str(entity).strip()
                if entity not in subdomain_dict['entities']:
                    subdomain_dict['entities'][entity] = {'uri': self.normalize_uri_component(entity), 'label': entity, 'type': 'Entity', 'tables': []}
                
                if pd.notna(table):
                    table = str(table).strip()
                    table_info = {'uri': self.normalize_uri_component(table), 'label': table, 'type': 'PhysicalTable'}
                    if table_info not in subdomain_dict['entities'][entity]['tables']:
                        subdomain_dict['entities'][entity]['tables'].append(table_info)
        
        total_domains = len(hierarchy)
        total_subdomains = sum(len(d['subdomains']) for d in hierarchy.values())
        total_entities = sum(sum(len(s['entities']) for s in d['subdomains'].values()) for d in hierarchy.values())
        logger.info(f"Hierarchy parsed: {total_domains} domains, {total_subdomains} subdomains, {total_entities} entities")
        
        return hierarchy
    
    def generate_rdf_triples(self, hierarchy: Dict[str, Dict[str, Any]]) -> List[Tuple]:
        """
        Convert hierarchical structure to RDF triples.
        """
        triples = []
        classes = {'DataDomain': META.DataDomain, 'SubDomain': META.SubDomain, 'Entity': META.Entity, 'PhysicalTable': META.PhysicalTable}
        properties = {'contains': META.contains, 'includes': META.includes, 'implements': META.implements}
        
        logger.info("Generating RDF triples from hierarchy")
        
        for domain_data in hierarchy.values():
            domain_uri = META[domain_data['uri']]
            triples.append((domain_uri, RDF.type, classes['DataDomain']))
            if domain_data.get('label'): triples.append((domain_uri, RDFS.label, Literal(str(domain_data['label']))))
            
            for subdomain_data in domain_data['subdomains'].values():
                subdomain_uri = META[subdomain_data['uri']]
                triples.append((subdomain_uri, RDF.type, classes['SubDomain']))
                if subdomain_data.get('label'): triples.append((subdomain_uri, RDFS.label, Literal(str(subdomain_data['label']))))
                triples.append((domain_uri, properties['contains'], subdomain_uri))
                
                for entity_data in subdomain_data['entities'].values():
                    entity_uri = META[entity_data['uri']]
                    triples.append((entity_uri, RDF.type, classes['Entity']))
                    if entity_data.get('label'): triples.append((entity_uri, RDFS.label, Literal(str(entity_data['label']))))
                    triples.append((subdomain_uri, properties['includes'], entity_uri))
                    
                    for table_data in entity_data['tables']:
                        table_uri = META[table_data['uri']]
                        triples.append((table_uri, RDF.type, classes['PhysicalTable']))
                        if table_data.get('label'): triples.append((table_uri, RDFS.label, Literal(str(table_data['label']))))
                        triples.append((table_uri, properties['implements'], entity_uri))
        
        logger.info(f"Generated {len(triples)} RDF triples")
        return triples
    
    def backup_current_data(self) -> Optional[str]:
        """
        Backup current RDF data before import.
        """
        if not self.config.import_behavior.backup_before_import:
            logger.info("Backup disabled in configuration")
            return None
        
        backup_dir = Path(self.config.import_behavior.backup_directory)
        backup_dir.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_file = backup_dir / f"backup_{timestamp}.ttl"
        
        try:
            self.triple_store.graph.serialize(destination=str(backup_file), format='turtle')
            logger.info(f"Created backup: {backup_file}")
            return str(backup_file)
        except Exception as e:
            logger.warning(f"Backup failed: {str(e)}")
            return None
    
    def import_excel_to_rdf(self, filepath: str) -> Dict[str, Any]:
        """
        Main orchestration method for Excel to RDF import.
        """
        logger.info(f"Starting Excel import from: {filepath}")
        import_summary = {'file': filepath, 'status': 'pending', 'stats': {}, 'validation': {}, 'backup_file': None, 'errors': []}
        
        try:
            df = self.read_excel_file(filepath)
            import_summary['stats']['total_rows'] = len(df)
            
            structure_validation = self.validate_excel_structure(df)
            if structure_validation['missing_columns']:
                import_summary['status'] = 'failed'
                import_summary['errors'] = structure_validation['missing_columns']
                return import_summary
            
            data_validation = self.validate_data_values(df)
            import_summary['validation'] = data_validation
            if data_validation['errors']:
                import_summary['status'] = 'failed'
                import_summary['errors'] = data_validation['errors']
                return import_summary
            
            hierarchy = self.parse_hierarchy(df)
            triples = self.generate_rdf_triples(hierarchy)
            import_summary['stats']['triples_generated'] = len(triples)
            
            if self.config.import_behavior.preview_before_commit:
                logger.info(f"Preview: Would import {len(triples)} triples")
            
            backup_file = self.backup_current_data()
            import_summary['backup_file'] = backup_file
            
            if self.config.import_behavior.strategy == 'replace':
                logger.info("Clearing existing data (replace strategy)")
                self.triple_store.graph = Graph()
                self.triple_store.graph.bind('meta', META)
            
            for triple in triples:
                self.triple_store.graph.add(triple)
            
            import_summary['status'] = 'success'
            logger.info(f"Import completed successfully: {len(triples)} triples added")
            
        except Exception as e:
            import_summary['status'] = 'error'
            import_summary['errors'].append(str(e))
            logger.error(f"Import failed: {str(e)}")
        
        return import_summary


def main():
    """
    Demonstrate Excel import functionality with educational examples.
    """
    logger.info("="*20 + " Excel Import Pipeline Demo " + "="*20)
    
    # Use the Excel file specified in configuration for the test
    data_file = Path(config.excel_import.file_settings.input_file)
    logger.info(f"Using Excel file from config: {data_file}")

    if not data_file.exists():
        logger.critical(f"Input file not found: {data_file}. Cannot run demonstration.")
        return

    try:
        importer = ExcelImporter()
        
        logger.info("--- Configuration Summary ---")
        logger.info(f"Domain column: '{importer.col_mappings.domain_column}'")
        logger.info(f"Entity column: '{importer.col_mappings.entity_column}'")
        
        logger.info("\n--- Starting Import Process ---")
        result = importer.import_excel_to_rdf(str(data_file))
        
        logger.info("\n--- Import Results ---")
        logger.info(f"Status: {result['status']}")
        logger.info(f"Rows processed: {result['stats'].get('total_rows', 0)}")
        logger.info(f"Triples generated: {result['stats'].get('triples_generated', 0)}")
        logger.info(f"Backup created: {result['backup_file']}")
        
        if result.get('errors'):
            logger.error(f"Import finished with errors: {result['errors']}")
        
        if result.get('validation', {}).get('warnings'):
            logger.warning(f"Validation warnings: {result['validation']['warnings']}")
        
        if result['status'] == 'success':
            logger.info("\n--- Demonstrating SPARQL Queries on Imported Data ---")
            
            # Query 1: Find all domains
            query1 = "SELECT ?domain ?label WHERE { ?domain a meta:DataDomain ; rdfs:label ?label . }"
            results1 = importer.triple_store.execute_sparql(query1)
            logger.info("Query: All Domains")
            for row in results1: logger.info(f"  - Found Domain: {row['label']}")
            
            # Query 2: Find all tables in the first domain found
            if results1:
                first_domain_label = results1[0]['label']
                query2 = f"""
                SELECT ?table_label WHERE {{
                    ?domain rdfs:label "{first_domain_label}" .
                    ?domain meta:contains* ?sub_entity .
                    ?sub_entity meta:includes* ?entity .
                    ?table meta:implements ?entity .
                    ?table rdfs:label ?table_label .
                }}
                """
                results2 = importer.triple_store.execute_sparql(query2)
                logger.info(f"\nQuery: All tables in '{first_domain_label}' domain")
                for row in results2: logger.info(f"  - Found Table: {row['table_label']}")

            logger.info(f"\nTotal triples in graph: {len(importer.triple_store.graph)}")

    except Exception as e:
        logger.error(f"An error occurred during the Excel import demonstration: {e}", exc_info=True)

    logger.info("="*20 + " Demonstration Finished " + "="*20)


if __name__ == "__main__":
    main()
