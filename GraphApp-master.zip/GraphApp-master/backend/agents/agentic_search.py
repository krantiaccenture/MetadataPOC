import os
from typing import Dict, TypedDict

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END

# Load environment variables from .env file
load_dotenv()

# Define the state for our LangGraph agent
class AgentState(TypedDict):
    """
    Represents the state of our Metadata agent.

    Attributes:
        prompt: The natural language prompt from the user.
        schema_summary: A summary of the graph's schema.
        response: The natural language response from the agent.
        error: Any error message that occurred during generation.
    """
    prompt: str
    schema_summary: str
    response: str
    error: str

class MetadataAgent:
    """
    An agentic class to answer questions about an RDF graph.
    """

    def __init__(self):
        """
        Initializes the agent, setting up the LangGraph graph and compiling it.
        """
        self.llm = ChatOpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.graph = self._build_graph()

    def _build_graph(self):
        """
        Builds the LangGraph graph with nodes and edges.
        """
        workflow = StateGraph(AgentState)
        workflow.add_node("generate_response", self.generate_response_node)
        workflow.set_entry_point("generate_response")
        workflow.add_edge("generate_response", END)
        return workflow.compile()

    def generate_response_node(self, state: AgentState) -> Dict[str, str]:
        """
        Generates a natural language response based on the user's prompt and schema summary.
        """
        prompt = state.get("prompt", "")
        schema_summary = state.get("schema_summary", "No schema provided.")
        
        if not prompt:
            return {"error": "Prompt is empty."}

        # Construct a more detailed prompt for the LLM
        system_message = (
            "You are an expert in RDF and graph databases. Your task is to analyze the provided RDF graph schema "
            "and answer the user's question in a clear, human-readable format. "
            "The user is a business analyst, so avoid technical jargon where possible.\n\n"
            "--- Schema Summary ---\n"
            f"{schema_summary}\n"
            "----------------------\n\n"
        )
        
        full_prompt = f"{system_message}\n\nUser Question: {prompt}"

        try:
            response = self.llm.invoke(full_prompt)
            return {"response": response.content, "error": None}
        except Exception as e:
            return {"error": f"An error occurred: {e}"}

    def run(self, prompt: str, schema_summary: str) -> Dict[str, str]:
        """
        Runs the agent with a given prompt and schema summary.

        Args:
            prompt: The user's natural language prompt.
            schema_summary: A string summary of the graph schema.

        Returns:
            The final state of the agent after execution.
        """
        initial_state = {"prompt": prompt, "schema_summary": schema_summary}
        return self.graph.invoke(initial_state)

