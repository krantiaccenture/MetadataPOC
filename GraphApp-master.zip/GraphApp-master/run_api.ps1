# This script runs the FastAPI application using uvicorn.
# The --reload flag enables auto-reloading when code changes.

Write-Host "Starting FastAPI server with uvicorn and opening docs..."
Write-Host "The browser might show an error for a second until the server is ready."
Write-Host "Press CTRL+C in this terminal to stop the server."

# Start Chrome - this command returns instantly
Start-Process "chrome.exe" "http://127.0.0.1:8000/docs"

# Start the server - this command will block the terminal
uvicorn backend.main:app --reload
