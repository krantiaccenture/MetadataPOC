"""
Configuration Manager for RDF Metadata Graph

Provides hierarchical configuration management with dot notation access.
Implements the proven config pattern from architect methodology.
"""

import sys
from pathlib import Path

# Add project root to path for imports
# This is crucial for making the module runnable as a script
project_root = Path(__file__).parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

import yaml
from typing import Any, Dict, Optional

# Use the centralized logger factory
from src.utils.logger_factory import get_component_logger

# Initialize a logger for this component
logger = get_component_logger('config_manager')

class ConfigDict(dict):
    """Enhanced dictionary with dot notation access and nested path support"""
    
    def __init__(self, data: dict = None):
        super().__init__()
        if data:
            self._deep_update(data)
    
    def __getattr__(self, key: str) -> Any:
        """Enable dot notation access: config.gui.window.width"""
        try:
            return self[key]
        except KeyError:
            raise AttributeError(f"'{self.__class__.__name__}' has no attribute '{key}'")
    
    def __setattr__(self, key: str, value: Any) -> None:
        """Enable dot notation assignment"""
        self[key] = value
    
    def _deep_update(self, data: dict) -> None:
        """Recursively convert nested dicts to ConfigDict instances"""
        for key, value in data.items():
            if isinstance(value, dict):
                self[key] = ConfigDict(value)
            else:
                self[key] = value
    
    def get_nested(self, path: str, default: Any = None) -> Any:
        """Get nested value using dot notation path"""
        keys = path.split('.')
        value = self
        try:
            for key in keys:
                value = value[key]
            return value
        except (KeyError, TypeError):
            return default

class ProjectConfigManager:
    """
    Manages project configuration files with hierarchical loading.
    Loads and merges all numbered YAML files from the config directory.
    """
    
    _instance: Optional['ProjectConfigManager'] = None
    _config: Optional[ConfigDict] = None
    
    def __new__(cls) -> 'ProjectConfigManager':
        """Singleton pattern implementation"""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        """Initialize configuration manager"""
        if self._config is None:
            self._load_configuration()
    
    def _load_configuration(self) -> None:
        """Load and merge all project configuration files"""
        config_dir = self._get_config_directory()
        
        # Find all numbered yaml files (e.g., 10_*.yaml, 15_*.yaml)
        config_files = sorted(config_dir.glob("[0-9][0-9]_*.yaml"))
        
        if not config_files:
            logger.error(f"No configuration files found in {config_dir}. Raising FileNotFoundError.")
            raise FileNotFoundError(f"No configuration files (e.g., 10_*.yaml) found in {config_dir}")
        
        merged_config = {}
        for config_file in config_files:
            try:
                with open(config_file, 'r', encoding='utf-8') as f:
                    file_config = yaml.safe_load(f)
                    if file_config:
                        merged_config = self._deep_merge(merged_config, file_config)
                        logger.debug(f"Successfully loaded and merged config from {config_file.name}")
            except Exception as e:
                logger.error(f"Error loading {config_file.name}: {e}", exc_info=True)
                raise
        
        self._config = ConfigDict(merged_config)
        logger.info(f"Configuration successfully loaded from {len(config_files)} files.")
    
    def _deep_merge(self, base: dict, override: dict) -> dict:
        """Deep merge two dictionaries, with override values taking precedence."""
        result = base.copy()
        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._deep_merge(result[key], value)
            else:
                result[key] = value
        return result
    
    def _get_config_directory(self) -> Path:
        """Get the configuration directory path, assuming it's a sibling of 'src'."""
        # Project root is the parent of the directory containing this file
        config_dir = project_root / "config"
        if not config_dir.exists():
            logger.error(f"Config directory not found at expected path: {config_dir}")
            raise FileNotFoundError(f"Config directory not found: {config_dir}")
        return config_dir
    
    def get_project_config(self) -> ConfigDict:
        """Get the complete project configuration."""
        if self._config is None:
            self._load_configuration()
        return self._config
    
    def reload_configuration(self) -> None:
        """Force a reload of the configuration from files."""
        logger.info("Reloading configuration...")
        self._config = None
        self._load_configuration()

# --- Public API ---
_config_manager = ProjectConfigManager()

def get_project_config() -> ConfigDict:
    """
    Get the project configuration with dot notation access.
    
    Usage:
        from config.config_manager import get_project_config
        config = get_project_config()
        width = config.gui.window.width
    """
    return _config_manager.get_project_config()

# --- Independent Test Block ---
if __name__ == "__main__":
    
    def demonstrate_config_access():
        """Show different ways to access configuration using the logger."""
        logger.info("="*20 + " Config Manager Demonstration " + "="*20)
        
        try:
            config = get_project_config()
            
            logger.info("1. Successfully retrieved configuration object.")
            
            # Use config values from the files to demonstrate loading
            app_name = config.get_nested('application.name', 'Default App Name')
            logger.info(f"2. Application Name from config: '{app_name}'")

            window_width = config.get_nested('gui.window.width', 'Not Found')
            logger.info(f"3. GUI window width from config: {window_width}")
            
            # Demonstrate accessing a whole section
            rdf_settings = config.get('rdf_settings', None)
            if rdf_settings:
                logger.info("4. RDF Settings section loaded successfully.")
                base_ns = rdf_settings.get('base_namespace', 'Not Found')
                logger.info(f"   - Base Namespace: {base_ns}")
            else:
                logger.warning("4. RDF Settings section not found in config.")

            logger.info("5. Testing reload functionality...")
            _config_manager.reload_configuration()
            logger.info("   - Configuration reloaded.")

        except Exception as e:
            logger.error(f"An error occurred during the demonstration: {e}", exc_info=True)
            logger.critical("Please ensure config files (e.g., '10_project_config.yaml') exist in the 'config/' directory.")
        
        logger.info("="*20 + " Demonstration Finished " + "="*20)
    
    demonstrate_config_access()
