"use client";

import { useGraphStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { getComponentLogger } from "@/lib/logger";

const logger = getComponentLogger('PropertiesPanel');

// Define the desired display order for node properties, matching the schema
const PROPERTY_ORDER = [
  "label",
  "nodeType",
  "comment",
  "contains",
  "includes",
  "implements",
  "has detail",
  "references",
  "part of hierarchy",
  "measures",
  "analyzes",
];

export function PropertiesPanel() {
  const { selectedNode } = useGraphStore();

  logger.debug("PropertiesPanel re-rendered. Selected node:", selectedNode);
  
  // Helper function to sort and filter attributes
  const getSortedAttributes = () => {
    if (!selectedNode?.attributes) return [];

    const attributes = selectedNode.attributes;
    const sortedKeys = Object.keys(attributes).sort((a, b) => {
      const indexA = PROPERTY_ORDER.indexOf(a);
      const indexB = PROPERTY_ORDER.indexOf(b);
      // If a key is not in our list, it goes to the end
      if (indexA === -1) return 1;
      if (indexB === -1) return -1;
      return indexA - indexB;
    });

    return sortedKeys;
  };

  const sortedAttributes = getSortedAttributes();

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>Properties</CardTitle>
      </CardHeader>
      <CardContent>
        {selectedNode ? (
          <div>
            <h3 className="font-bold text-lg mb-4 border-b pb-2">{selectedNode.label}</h3>
            <div className="overflow-auto">
              <table className="w-full text-sm">
                <tbody>
                  {sortedAttributes.map((key) => (
                    <tr key={key} className="border-b">
                      <td className="py-2 pr-2 font-semibold capitalize align-top">{key}</td>
                      <td className="py-2 pl-2">
                        {Array.isArray(selectedNode.attributes[key])
                          ? (selectedNode.attributes[key] as any[]).map((value, index) => (
                              <div key={index}>{String(value)}</div>
                            ))
                          : String(selectedNode.attributes[key])}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <p className="text-sm text-gray-500">
            Click on a node in the graph to see its details.
          </p>
        )}
      </CardContent>
    </Card>
  );
}
