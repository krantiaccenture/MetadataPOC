"use client";

import React, { useState } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { getComponentLogger } from "@/lib/logger";

const logger = getComponentLogger('MetadataAgentPanel');
const API_URL = 'http://127.0.0.1:8000/agent-query';

const MetadataAgentPanel = () => {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    if (!prompt.trim()) {
      setError("Please enter a question.");
      return;
    }

    logger.info(`Submitting prompt: "${prompt}"`);
    setIsLoading(true);
    setError('');
    setResponse('');

    try {
      const result = await axios.post(API_URL, { prompt });
      logger.info("Received response from agent:", result.data.response);
      setResponse(result.data.response);
    } catch (err: any) {
      const errorMessage = err.response?.data?.detail || "An unexpected error occurred.";
      logger.error("Error calling agent API:", errorMessage);
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Metadata Agent</CardTitle>
        <Button onClick={handleSubmit} disabled={isLoading}>
          {isLoading ? 'Thinking...' : 'Submit'}
        </Button>
      </CardHeader>
      <CardContent className="flex-grow flex flex-col space-y-4 overflow-hidden">
        {/* Question Section: Takes up 1/3 of the height */}
        <div className="flex flex-col space-y-2 h-1/3">
          <label htmlFor="prompt-textarea" className="font-semibold">Your Question:</label>
          <Textarea
            id="prompt-textarea"
            placeholder="e.g., 'What is the purpose of the Sales data domain?'"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="h-full resize-none" // Use h-full to fill parent
          />
        </div>
        {/* Response Section: Takes remaining space */}
        <div className="flex-grow flex flex-col space-y-2 overflow-hidden">
            <label htmlFor="response-display" className="font-semibold">Agent's Response:</label>
            <div 
                id="response-display" 
                className="w-full h-full p-2 border rounded-md bg-muted overflow-y-auto"
                style={{ whiteSpace: 'pre-wrap' }} // Ensures text wraps
            >
                {error ? <span className="text-red-500">{error}</span> : response}
            </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default MetadataAgentPanel;
