"use client";

import { useGraphStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { getComponentLogger } from "@/lib/logger";

const logger = getComponentLogger('FilterPanel');

export function FilterPanel() {
  // Get state and actions from the Zustand store
  const { allNodeTypes, filters, setFilters, theme, toggleTheme } = useGraphStore();

  logger.debug("FilterPanel re-rendered. All node types:", allNodeTypes);
  logger.debug("Current filters:", filters);

  const handleNodeTypeChange = (nodeType: string, checked: boolean) => {
    // Create a new set for easy manipulation
    const newDisplayNodeTypes = new Set(filters.displayNodeTypes);
    
    if (checked) {
      newDisplayNodeTypes.add(nodeType);
    } else {
      newDisplayNodeTypes.delete(nodeType);
    }
    
    const newFilters = {
      ...filters,
      displayNodeTypes: Array.from(newDisplayNodeTypes),
    };

    logger.debug("Setting new filters:", newFilters);
    setFilters(newFilters);
  };

  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Filter by Node Type</CardTitle>
        <div className="flex items-center space-x-2">
          <Switch
            id="theme-switch"
            checked={theme === 'dark'}
            onCheckedChange={toggleTheme}
          />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {allNodeTypes.sort().map((nodeType) => (
            <div key={nodeType} className="flex items-center space-x-2">
              <Checkbox
                id={nodeType}
                checked={filters.displayNodeTypes.includes(nodeType)}
                onCheckedChange={(checked) => handleNodeTypeChange(nodeType, !!checked)}
              />
              <label
                htmlFor={nodeType}
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                {nodeType}
              </label>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
