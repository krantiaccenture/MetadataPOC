"use client";

import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable";
import { PropertiesPanel } from "./properties-panel";
import { FilterPanel } from './filter-panel';
import MetadataAgentPanel from './metadata-agent-panel';
import dynamic from 'next/dynamic';

// Dynamically import GraphCanvas to ensure it only runs on the client-side
const GraphCanvas = dynamic(() => import('@/components/graph-canvas'), {
  ssr: false,
  loading: () => <p className="flex h-full w-full items-center justify-center">Loading graph...</p>,
});

export function MainLayout() {
    return (
        <ResizablePanelGroup
            direction="horizontal"
            className="h-screen w-screen rounded-lg border"
        >
            <ResizablePanel defaultSize={20}>
                <ResizablePanelGroup direction="vertical" className="h-full">
                    <ResizablePanel defaultSize={25}>
                        <FilterPanel />
                    </ResizablePanel>
                    <ResizableHandle />
                    <ResizablePanel defaultSize={75}>
                        <MetadataAgentPanel />
                    </ResizablePanel>
                </ResizablePanelGroup>
            </ResizablePanel>
            <ResizableHandle withHandle />
            <ResizablePanel defaultSize={60}>
                <GraphCanvas />
            </ResizablePanel>
            <ResizableHandle withHandle />
                       <ResizablePanel defaultSize={0}>
               <div className="p-4 h-full">
                   <PropertiesPanel />
               </div>
           </ResizablePanel>
        </ResizablePanelGroup>
    )
}
