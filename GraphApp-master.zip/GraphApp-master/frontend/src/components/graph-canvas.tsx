"use client";

import React, { useEffect, useRef, useState } from 'react';
import ForceGraph2D, { ForceGraphMethods, NodeObject, LinkObject } from 'react-force-graph-2d';
import { useGraphStore, GraphNode, GraphLink } from '@/lib/store';
import { getComponentLogger } from '@/lib/logger';

const LINK_TEXT_COLOR = '#6E6E6E';
const BG_LIGHT = '#F9FAFB';
const BG_DARK = '#000000';

// The library adds coordinates and velocity to the node objects.
type ForceNode = GraphNode & {
  x?: number;
  y?: number;
  vx?: number;
  vy?: number;
  nodeType?: string; // Add nodeType to our extended type
};

// Theme-aware node colors
const NODE_COLORS_LIGHT: Record<string, string> = {
  'Data Domain': '#1f77b4',
  'Sub Domain': '#ff7f0e',
  'Data Entity': '#2ca02c',
  'Physical Table': '#d62728',
  default: '#7f7f7f'
};

// Node size (radius) by type
const NODE_SIZES: Record<string, number> = {
  'Data Domain': 12,
  'Sub Domain': 10,
  'Data Entity': 8,
  'Physical Table': 5,
  default: 5
};

const NODE_COLORS_DARK: Record<string, string> = {
  'Data Domain': '#3A5FA0', // muted blue
  'Sub Domain': '#876330',  // soft ochre
  'Data Entity': '#3F7B3F', // earthy green
  'Physical Table': '#823A3A', // muted brick red
  default: '#6F6F6F'        // mid-gray
};

const getNodeColor = (node: NodeObject, theme: 'light' | 'dark') => {
  const forceNode = node as ForceNode;
  const nodeType = forceNode.nodeType || 'default';
  const palette = theme === 'dark' ? NODE_COLORS_DARK : NODE_COLORS_LIGHT;
  return palette[nodeType] || palette.default;
};

const getLinkColor = () => LINK_TEXT_COLOR;

// --- Hierarchical Radial Positioning Helper ---
function getHierarchicalRadialPositions(
  nodes: GraphNode[],
  links: GraphLink[],
  tableClusterThreshold = 10 // max tables before clustering
): (GraphNode & { x?: number; y?: number; fx?: number; fy?: number })[] {
  // Find the Data Domain node
  const dataDomain = nodes.find(n => n.nodeType === 'Data Domain');
  if (!dataDomain) return nodes;

  // Find Sub Domains/Data Entities (children of Data Domain)
  const firstRingIds = links
    .filter(l => l.source === dataDomain.id || l.target === dataDomain.id)
    .map(l => (l.source === dataDomain.id ? l.target : l.source));

  // Place Data Domain at center and fix it
  let positioned: (GraphNode & { x?: number; y?: number; fx?: number; fy?: number })[] = nodes.map(n => {
    if (n.id === dataDomain.id) {
      return { ...n, x: 0, y: 0, fx: 0, fy: 0 };
    }
    return { ...n };
  });

  // Place Sub Domains/Data Entities in first ring
  const firstRingRadius = 160;
  const firstRingAngleStep = (2 * Math.PI) / firstRingIds.length;
  firstRingIds.forEach((id, i) => {
    const idx = positioned.findIndex(n => n.id === id);
    if (idx !== -1) {
      positioned[idx].x = Math.cos(i * firstRingAngleStep) * firstRingRadius;
      positioned[idx].y = Math.sin(i * firstRingAngleStep) * firstRingRadius;
    }
  });

  // --- Physical Table fan/cluster logic ---
  const newNodes: (GraphNode & { x?: number; y?: number; fx?: number; fy?: number })[] = [];
  const newLinks: GraphLink[] = [...links];

  firstRingIds.forEach((entityId) => {
    // Find Physical Tables for this Data Entity
    const tableLinks = links.filter(l => l.source === entityId || l.target === entityId);
    const tableIds = tableLinks
      .map(l => (l.source === entityId ? l.target : l.source))
      .filter(id => {
        const n = nodes.find(n => n.id === id);
        return n && n.nodeType === 'Physical Table';
      });

    // Get parent position
    const parentIdx = positioned.findIndex(n => n.id === entityId);
    if (parentIdx === -1) return;
    const parent = positioned[parentIdx];

    // Cluster if too many tables
    if (tableIds.length > tableClusterThreshold) {
      // Create a cluster node
      const clusterId = `${entityId}__physical_tables_cluster`;
      newNodes.push({
        id: clusterId,
        label: `Physical Tables (${tableIds.length})`,
        nodeType: 'Physical Table Cluster',
        attributes: {},
        x: parent.x! + 60, // offset from parent
        y: parent.y! + 60,
      });
      newLinks.push({ source: entityId, target: clusterId, label: 'has many tables' });
    } else {
      // Place tables in a fan/arc around the parent
      const arc = Math.PI; // 180 degrees
      const startAngle = -arc / 2;
      const tableRadius = 60;
      tableIds.forEach((tid, j) => {
        const angle = startAngle + (arc * j) / Math.max(1, tableIds.length - 1);
        const idx = positioned.findIndex(n => n.id === tid);
        if (idx !== -1) {
          positioned[idx].x = parent.x! + Math.cos(angle) * tableRadius;
          positioned[idx].y = parent.y! + Math.sin(angle) * tableRadius;
        }
      });
    }
  });

  // Add cluster nodes to positioned array
  if (newNodes.length > 0) {
    positioned = positioned.concat(newNodes);
  }

  // Return positioned nodes
  return positioned;
}

const logger = getComponentLogger('GraphCanvas');

const GraphCanvas = () => {
  const { nodes, links, isLoading, error, fetchGraphData, setSelectedNode, theme } = useGraphStore();
  const fgRef = useRef<ForceGraphMethods<NodeObject, LinkObject<NodeObject, NodeObject>> | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  useEffect(() => {
    let timeoutId: ReturnType<typeof setTimeout>;

    const observer = new ResizeObserver(entries => {
      // Clear the previous timeout to debounce the resize event
      clearTimeout(timeoutId);

      // Set a new timeout to update dimensions after a pause
      timeoutId = setTimeout(() => {
        const { width, height } = entries[0].contentRect;
        if (width > 0 && height > 0) {
          setDimensions({ width, height });
        }
      }, 300); // Debounce delay of 300ms
    });

    const currentContainer = containerRef.current;
    if (currentContainer) {
      observer.observe(currentContainer);
    }

    // Cleanup observer and timeout on component unmount
    return () => {
      if (currentContainer) {
        observer.unobserve(currentContainer);
      }
      clearTimeout(timeoutId);
    };
  }, []);

  useEffect(() => {
    logger.info("GraphCanvas component mounted. Fetching data...");
    fetchGraphData();
  }, [fetchGraphData]);

  useEffect(() => {
    // Fit graph to canvas whenever data or dimensions change
    if (nodes.length > 0 && dimensions.width > 0 && fgRef.current) {
      setTimeout(() => {
        fgRef.current?.zoomToFit(400, 75);
      }, 200);
    }
  }, [nodes, dimensions]);

  const handleNodeClick = (node: NodeObject) => {
    const forceNode = node as ForceNode;
    logger.info(`Node clicked: ${forceNode.label} (ID: ${forceNode.id})`);
    setSelectedNode(forceNode);
    
    const fg = fgRef.current;
    if (fg && forceNode.x !== undefined && forceNode.y !== undefined) {
      fg.centerAt(forceNode.x, forceNode.y, 1000);
      fg.zoom(8, 1000);
    }
  };

  if (isLoading) {
    return <div className="flex h-full w-full items-center justify-center">Loading graph data...</div>;
  }

  if (error) {
    return <div className="flex h-full w-full items-center justify-center text-red-500">{error}</div>;
  }

  logger.info(`Rendering graph with ${nodes.length} nodes and ${links.length} links.`);

  // --- Use hierarchical radial positions as initial hints ---
  const positionedNodes = getHierarchicalRadialPositions(nodes, links);

  return (
    <div ref={containerRef} className="h-full w-full border rounded-lg" style={{ backgroundColor: theme === 'dark' ? BG_DARK : BG_LIGHT }}>
      {dimensions.width > 0 ? (
        <ForceGraph2D
          ref={fgRef as React.MutableRefObject<ForceGraphMethods<NodeObject, LinkObject<NodeObject, NodeObject>>>}
          width={dimensions.width}
          height={dimensions.height}
          graphData={{ nodes: structuredClone(positionedNodes), links: structuredClone(links) }}
          nodeColor={(n)=>getNodeColor(n, theme)}
          linkColor={getLinkColor}
          linkDirectionalArrowLength={3.5}
          linkDirectionalArrowRelPos={1}
          linkDirectionalParticles={1}
          linkDirectionalParticleSpeed={0.003}
          linkDirectionalParticleWidth={2}
          linkDirectionalParticleColor={() => LINK_TEXT_COLOR}
          onNodeClick={handleNodeClick as (node: object) => void}
          nodeCanvasObject={(node, ctx: CanvasRenderingContext2D, globalScale) => {
            const forceNode = node as ForceNode;
            const label = forceNode.label || '';
            
            // Use auto-coloring for the node
            const color = getNodeColor(node, theme);
            const nodeRadius = NODE_SIZES[forceNode.nodeType as string] ?? NODE_SIZES.default;
            // Draw the node as a circle
            ctx.beginPath();
            if (forceNode.x !== undefined && forceNode.y !== undefined) {
              ctx.arc(forceNode.x, forceNode.y, nodeRadius, 0, 2 * Math.PI, false);
              ctx.fillStyle = color;
              ctx.fill();
            }

            // Draw the label conditionally based on node type and zoom level
            const ZOOM_THRESHOLD = 4;
            const isPhysicalTable = forceNode.nodeType === 'Physical Table';
            
            // Show label if it's not a PhysicalTable OR if it is and we are zoomed in
            if (!isPhysicalTable || globalScale > ZOOM_THRESHOLD) {
              const fontSize = 12 / globalScale;
              ctx.font = `${fontSize}px Sans-Serif`;
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.fillStyle = LINK_TEXT_COLOR;
              if (forceNode.x !== undefined && forceNode.y !== undefined) {
                ctx.fillText(label, forceNode.x, forceNode.y + nodeRadius + 5);
              }
            }
          }}
        />
      ) : (
        <div className="h-full w-full" />
      )}
    </div>
  );
};

export default GraphCanvas;
