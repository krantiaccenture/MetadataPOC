import { create } from 'zustand';
import axios from 'axios';

// Define the structure of our nodes and links from the API
export interface GraphNode {
  id: string;
  label: string;
  nodeType: string; // Crucial for filtering by type
  attributes: { [key: string]: unknown }; // All other properties from the backend
}

export interface GraphLink {
  source: string; // Should be node ID string
  target: string; // Should be node ID string
  label: string;
  [key: string]: unknown; // Allow other properties
}

// --- New ---
// Define the structure for our filter criteria
interface FilterCriteria {
  displayNodeTypes: string[];
  // Hierarchical filter placeholders
  // domain: string;
  // subdomain: string;
  // entity: string;
}

// Define the state structure for our store
interface GraphState {
  // Unfiltered source of truth
  unfilteredNodes: GraphNode[];
  unfilteredLinks: GraphLink[];
  // Filtered data for display
  nodes: GraphNode[];
  links: GraphLink[];
  // UI and interaction state
  selectedNode: GraphNode | null;
  isLoading: boolean;
  error: string | null;
  // --- New: Theme state ---
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  // Filter state and actions
  filters: FilterCriteria;
  allNodeTypes: string[]; // To populate filter UI
  setFilters: (newFilters: Partial<FilterCriteria>) => void;
  // Original actions
  fetchGraphData: () => Promise<void>;
  setSelectedNode: (node: GraphNode | null) => void;
}

const API_URL = 'http://127.0.0.1:8000/graph';

export const useGraphStore = create<GraphState>((set, get) => ({
  // --- Initial State ---
  unfilteredNodes: [],
  unfilteredLinks: [],
  nodes: [],
  links: [],
  selectedNode: null,
  isLoading: false,
  error: null,
  theme: 'dark', // Default to dark mode
  allNodeTypes: [],
  filters: {
    displayNodeTypes: [],
  },

  // --- Actions ---

  // Action to toggle the theme
  toggleTheme: () => {
    set((state) => ({ theme: state.theme === 'light' ? 'dark' : 'light' }));
  },

  // Action to fetch data from the backend
  fetchGraphData: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await axios.get<{ nodes: GraphNode[]; links: GraphLink[] }>(API_URL);
      const fetchedNodes = response.data.nodes;
      const fetchedLinks = response.data.links;

      // --- New: Populate allNodeTypes for the filter UI ---
      const uniqueNodeTypes = [...new Set(fetchedNodes.map(n => n.nodeType))];
      
      set({
        unfilteredNodes: fetchedNodes,
        unfilteredLinks: fetchedLinks,
        nodes: fetchedNodes, // Initially, display all nodes
        links: fetchedLinks, // Initially, display all links
        allNodeTypes: uniqueNodeTypes,
        filters: { // By default, all node types are selected
          ...get().filters,
          displayNodeTypes: uniqueNodeTypes,
        },
        isLoading: false,
      });
    } catch (error) {
      console.error("Failed to fetch graph data:", error);
      set({ error: 'Failed to load graph data.', isLoading: false });
    }
  },

  // Action to set the currently selected node
  setSelectedNode: (node) => {
    set({ selectedNode: node });
  },
  
  // --- New: Action to update filters and apply them ---
  setFilters: (newFilters) => {
    const { unfilteredNodes, unfilteredLinks } = get();
    const currentFilters = get().filters;

    const updatedFilters = { ...currentFilters, ...newFilters };

    // 1. Filter nodes based on the selected displayNodeTypes
    const filteredNodes = unfilteredNodes.filter(node => 
      updatedFilters.displayNodeTypes.includes(node.nodeType)
    );
    const filteredNodeIds = new Set(filteredNodes.map(n => n.id));

    // 2. Filter links to only include those connecting the filtered nodes
    const filteredLinks = unfilteredLinks.filter(link =>
      filteredNodeIds.has(link.source) && filteredNodeIds.has(link.target)
    );

    set({
      filters: updatedFilters,
      nodes: filteredNodes,
      links: filteredLinks,
      selectedNode: null, // Deselect node when filter changes
    });
  },
}));
