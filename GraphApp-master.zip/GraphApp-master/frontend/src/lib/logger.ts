// A simple logger factory for the frontend
// Mimics the component-based pattern from the Python backend

const getTimestamp = () => new Date().toISOString();

// Define log levels
const LogLevel = {
  DEBUG: 0,
  INFO: 1,
  WARN: 2,
  ERROR: 3,
};

// Set the global log level for the application
// During development, we can set this to DEBUG. For production, we'd set it to INFO or WARN.
const APP_LOG_LEVEL = LogLevel.DEBUG;

const log = (level: number, componentName: string, message: string, ...args: unknown[]) => {
  if (level >= APP_LOG_LEVEL) {
    const levelName = Object.keys(LogLevel).find(key => LogLevel[key as keyof typeof LogLevel] === level);
    console.log(`[${getTimestamp()}] [${levelName}] [${componentName}] -`, message, ...args);
  }
};

export const getComponentLogger = (componentName: string) => {
  return {
    debug: (message: string, ...args: unknown[]) => log(LogLevel.DEBUG, componentName, message, ...args),
    info: (message: string, ...args: unknown[]) => log(LogLevel.INFO, componentName, message, ...args),
    warn: (message: string, ...args: unknown[]) => log(LogLevel.WARN, componentName, message, ...args),
    error: (message: string, ...args: unknown[]) => log(LogLevel.ERROR, componentName, message, ...args),
  };
};