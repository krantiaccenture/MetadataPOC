import { MainLayout } from "@/components/main-layout";

export default function Home() {
  return (
    <main className="h-screen">
      <MainLayout />
    </main>
  );
}
