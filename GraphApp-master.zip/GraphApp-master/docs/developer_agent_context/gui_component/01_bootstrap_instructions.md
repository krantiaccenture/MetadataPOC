# GUI Component - Implementation Overview

## 🎯 **Component Goal**
The GUI Layer for the RDF Metadata Graph application provides an interactive, visual interface to the underlying RDF data, built as a modern web application using Next.js and React.

---

## ✅ **Completed Foundation (Phase 2 & 3)**
- **Web-Based GUI**: A complete migration from a PyQt6 desktop application to a Next.js frontend.
- **Interactive Graph Canvas**: A `GraphCanvas` component using `react-force-graph-2d` provides a rich visualization of the RDF graph.
- **API-Driven Rendering**: The canvas is connected to a FastAPI backend via a Zustand store. It renders nodes and edges based on data fetched from the API.
- **Component-Based Layout**: The UI is built with reusable React components, arranged in a resizable layout.
- **State Management**: Client-side state, including the graph data, filters, and selected nodes, is managed centrally by a Zustand store (`useGraphStore`).

---

## 🏗️ **Component Architecture**

### **Frontend Layer (Next.js) - Implemented**
```
Frontend (Next.js)
├── Graph Canvas - Interactive visualization with react-force-graph-2d (COMPLETE)
├── Properties Panel - Displays node attributes (COMPLETE)
├── Filter Panel - Filters graph by node type (COMPLETE)
├── Metadata Agent Panel - Natural language query interface (COMPLETE)
├── Main Layout - Resizable panel layout (COMPLETE)
└── State Management (Zustand) - Central state store (COMPLETE)
```

### **Main UI Components**
1.  **MainLayout (Top-Level)**
    *   Uses `react-resizable-panels` to create the main splitter layout, arranging the other panels.
2.  **GraphCanvas (Central)**
    *   Renders the graph using `react-force-graph-2d`.
    *   Handles node click events to update the selected node in the Zustand store.
3.  **PropertiesPanel (Right)**
    *   Displays detailed attributes of the selected node.
    *   Subscribes to changes in the `selectedNode` part of the Zustand store.
4.  **FilterPanel (Left)**
    *   Displays a list of checkboxes for each node type.
    *   Allows users to show or hide nodes of a certain type, updating the `filters` in the Zustand store.
5.  **MetadataAgentPanel (Left)**
    *   Provides a text area for users to ask natural language questions about the graph.
    *   Calls a backend API endpoint (`/agent-query`) and displays the textual response from the AI agent.

---

## 🔑 **Core Implementation Standards**
1.  **Separation of Concerns**: The frontend React components are cleanly separated from the backend API. The UI components consume data from the Zustand store and dispatch actions to it.
2.  **Performance**: The `GraphCanvas` is optimized by cloning data passed to it, preventing state mutation issues.
3.  **Component-Based**: The entire UI is built from modular, reusable React components with specific purposes.
4.  **Pathing and Imports**: The code uses TypeScript path aliases (`@/`) for clean and maintainable imports.

This feature-complete UI is ready for the next phase of development: adding advanced interactivity and editing capabilities.
