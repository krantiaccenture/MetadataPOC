# GUI Component - Technical Implementation Summary

## 🎯 **Goal**
This document outlines the technical implementation of the completed GUI layer, focusing on the `GraphCanvas` and its integration into the `MainWindow`.

---

## 1. **File and Class Structure**

The following files were created and implemented in the `src/gui/` directory:

*   `src/gui/main_window.py`
    *   **Class**: `MainWindow(QMainWindow)`
    *   **Description**: The main application window. It initializes and arranges all GUI components. It sets the `GraphCanvas` as its central widget.
*   `src/gui/graph_canvas.py`
    *   **Class**: `GraphCanvas(QWidget)`
    *   **Description**: The core visualization component. It is responsible for drawing the graph and handling all user interactions.
*   `src/gui/__init__.py`
    *   This file makes the `gui` directory a Python package.

---

## 2. **`GraphCanvas` Implementation Summary**

### **Initialization (`__init__`)**
1.  Accepts a `TripleStore` instance in its constructor to access the live graph data.
2.  Loads all graph display settings (node colors, sizes, layouts, etc.) from the project's configuration file (`config/10_project_config.yaml`).
3.  Initializes a `networkx.DiGraph` to manage the graph structure for layout and rendering.
4.  Initializes state variables for interaction handling (zoom, pan, drag).

### **Data Loading and Layout**
1.  A method `load_graph_from_triplestore()` populates the `networkx` graph from the `TripleStore`.
2.  It filters the nodes to display based on a `display_level` setting in the configuration (e.g., only show up to the `Entity` level).
3.  A layout is calculated via the `_calculate_layout()` method, which can use standard `networkx` layouts or a custom `_calculate_custom_hierarchical_layout()` for a sunburst view.
4.  Node positions are calculated and stored.

### **Rendering (`paintEvent`)**
1.  The `paintEvent` method is overridden to perform all drawing using `QPainter` with antialiasing enabled.
2.  A transformation is applied to the painter to handle the current pan and zoom state.
3.  **Edges**: Edges are drawn as lines with arrowheads, correctly pointing from parent to child in the business hierarchy.
4.  **Nodes**: Nodes are drawn as ellipses.
    *   The color for each node is determined by its RDF type, based on the configuration.
    *   The size of the node and its label's font size are determined by the `_calculate_node_size_and_font()` method to ensure readability.
    *   The node's `rdfs:label` is drawn inside the ellipse, with wrapping and color contrast logic.

### **Interaction Handling**
1.  **Mouse Events**: `mousePressEvent`, `mouseMoveEvent`, and `mouseReleaseEvent` are implemented to handle user interactions.
    *   **Left Button**: Drags a node.
    *   **Middle/Right Button**: Pans the canvas.
2.  **Zoom**: The `wheelEvent` handles zooming. The implementation correctly adjusts the pan offset to ensure the view zooms in and out relative to the cursor's position.
3.  **Hover**: `mouseMoveEvent` also tracks the hovered node to display an informative tooltip.

### **Advanced Sizing Logic**
- The `_calculate_node_size_and_font` method implements a sophisticated multi-step process to ensure labels are readable:
    1. It starts with a base node size defined in the config.
    2. It attempts to fit the label by wrapping the text.
    3. If wrapping is not enough, it iteratively shrinks the font size down to a configured minimum.
    4. If the text still doesn't fit, it grows the node's diameter to accommodate the text at the minimum font size.

---

## 3. **`MainWindow` Implementation Summary**

1.  **Initialization (`__init__`)**:
    *   Sets up the main window's title and size from the configuration.
2.  **Component Integration and Data Loading**:
    *   Instantiates the `TripleStore` and `ExcelImporter`.
    *   Implements an intelligent `load_data` method:
        *   It first attempts to load a pre-saved `imported_graph.ttl` file for fast startup.
        *   If the file doesn't exist, it runs the full `ExcelImporter` process and saves the resulting graph as `imported_graph.ttl` for future runs.
    *   Instantiates the `GraphCanvas`, passing the populated `TripleStore` to it.
    *   Sets the `GraphCanvas` as the central widget.

---

## 4. **`main.py` Execution**

The main application entry point (`src/main.py`) was updated to:
1.  Create a `QApplication` instance.
2.  Create and show the `MainWindow`.
3.  Start the Qt event loop (`sys.exit(app.exec())`).

This implementation provides a robust and feature-rich visualization foundation for the application. 