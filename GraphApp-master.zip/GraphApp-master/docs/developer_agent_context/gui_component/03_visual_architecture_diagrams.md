# GUI Component - Visual Architecture

## 🎯 **Goal**
This document provides a visual representation of the GUI component architecture. It illustrates how the different parts of the user interface will be organized and how they interact.

---

## 🏗️ **High-Level Component Diagram**

This diagram shows the main widgets that compose the application's `MainWindow`.

```mermaid
graph TD
    subgraph MainWindow
        A[Toolbar] --> B{GraphCanvas};
        B --> C[PropertiesPanel];
        B --> D[SPARQLPanel];
        A --> E[TripleStore]
    end

    subgraph "RDF Engine (Existing)"
        E[TripleStore]
    end

    B -- "Reads graph data from" --> E;

    style MainWindow fill:#f9f9f9,stroke:#333,stroke-width:2px
    style A fill:#FADBD8,stroke:#C0392B,stroke-width:2px
    style B fill:#D1F2EB,stroke:#1ABC9C,stroke-width:4px
    style C fill:#FEF9E7
    style D fill:#FEF9E7
    style E fill:#E8DAEF
```

---

## 🔧 **Component Breakdown**

*   **MainWindow**: The main container for the entire application interface.
    *   **Toolbar (Top - COMPLETE)**: Sits at the top, providing buttons for high-level actions like layout switching, view control, data refresh, and image export.
    *   **GraphCanvas (Central Widget - COMPLETE)**: The core component, responsible for rendering and interactive visualization of the RDF graph. It fetches data directly from the `TripleStore` and features a refined interaction model (single-click, double-click, drag, pan, zoom).
    *   **PropertiesPanel (Right - COMPLETE)**: Sits on the right side. It displays detailed information about a node or edge that the user selects in the `GraphCanvas`.
    *   **SPARQLPanel (Bottom - COMPLETE)**: Sits at the bottom. It contains a text editor for writing SPARQL queries and a table for displaying the results.

---

## 🔄 **Interaction Flow**

1.  **Application Start**: The `MainWindow` is created.
2.  **Data Loading**: The `RDF Engine` loads the graph data into the `TripleStore` (this is already implemented).
3.  **Canvas Rendering**: The `GraphCanvas` reads the graph from the `TripleStore` and renders the initial visualization.
4.  **User Interaction**:
    *   The user interacts with the `GraphCanvas` (single-clicks, double-clicks, drags, zooms).
    *   If the user selects a node or edge, the `GraphCanvas` signals the `PropertiesPanel` to update and display its data.
    *   A double-click on a node re-centers the graph view.
5.  **Querying**:
    *   The user types a query into the `SPARQLPanel`.
    *   The query is executed against the `TripleStore`.
    *   The results are displayed in the `SPARQLPanel`'s results table, and the `GraphCanvas` updates to show the results visually.

This architecture ensures a clean separation of concerns, where the `GraphCanvas` is the central hub for visualization, and other panels react to events originating from it.
