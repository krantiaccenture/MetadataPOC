# GUI Component - Feature Checklist

## 📋 **Instructions**
This document serves as a checklist of the core features and standards that have been implemented in the GUI layer. It verifies that the final implementation aligns with the project's architectural and functional requirements.

---

### **1. Core Responsibility**
- **[✅] Status**: Implemented
- **Description**: The GUI layer is responsible for visualizing the RDF graph and allowing user interaction. It receives its data from the RDF Engine's `TripleStore` class.

---

### **2. Component-Based Architecture**
- **[✅] Status**: Implemented
- **Description**: The GUI is built around a central `GraphCanvas` widget, which handles all rendering and interaction. This component is instantiated and managed by the `MainWindow`.

---

### **3. Configuration-Driven Styling**
- **[✅] Status**: Implemented
- **Description**: All styling information (node colors, sizes, fonts, layouts, etc.) is loaded from the `config/10_project_config.yaml` file. There are no hardcoded styling values in the GUI source code.

---

### **4. Interaction Features**
- **[✅] Status**: Implemented
- **Description**: The `GraphCanvas` supports all required interactive features:
    1.  **Node Dragging**: Users can move nodes with the left mouse button.
    2.  **Zooming**: Users can zoom in and out using the mouse wheel. The zoom is centered on the cursor.
    3.  **Panning**: Users can pan the canvas using the middle or right mouse button.
    4.  **Hover Tooltips**: Hovering on a node displays its key metadata.

---

### **5. Performance Standards**
- **[✅] Status**: Met
- **Description**: The GUI is designed to remain smooth and responsive for graphs containing up to 500 nodes.

---

### **6. Separation of Concerns**
- **[✅] Status**: Adhered to
- **Description**: The GUI layer is cleanly separated from the RDF engine. The visualization components *read* data from the `TripleStore` but do not directly modify it, upholding the defined architectural pattern.

---

### **7. Advanced Features**
- **[✅] Status**: Implemented
- **Description**: Beyond the initial scope, the following advanced features were implemented:
    - **Custom Hierarchical Layout**: A special layout algorithm that visualizes the graph in a sunburst pattern based on the business hierarchy.
    - **Refined Interaction Model**: The canvas distinguishes between different mouse actions for intuitive control:
        - **[✅] Single-Click**: Selects/deselects a node and displays its properties.
        - **[✅] Double-Click**: Re-centers the view on a node with a dynamic radial layout.
        - **[✅] Click-and-Drag**: Moves a node while displaying its properties.
    - **Dynamic Node Sizing**: An algorithm that automatically adjusts node and font sizes to ensure text labels are always readable and fit correctly.

---

### **8. Toolbar Functionality**
- **[✅] Status**: Implemented
- **Description**: A toolbar provides easy access to key functions:
    - **Layout Switching**: Buttons to change the graph layout on the fly.
    - **View Controls**: Zoom in, zoom out, and fit-to-view actions.
    - **Data Refresh**: A button to reload the graph from the source Excel file.
    - **Image Export**: Functionality to save the current view as an image.
