# RDF Engine Component - Bootstrap Instructions

## 🎯 **COMPONENT OVERVIEW**

**Component**: RDF Engine Foundation with Excel Import and Agentic Search  
**Purpose**: Core RDF triple store with configurable Excel-to-Turtle data ingestion and natural language querying.
**Priority**: Phase 1 Foundation - All other components depend on this  
**Educational Focus**: RDF fundamentals, SPARQL basics, business metadata modeling, agentic AI systems.

### **Key Requirements**
- **RDF Triple Store**: CRUD operations using rdflib
- **Excel Import Pipeline**: Configurable column mapping with validation
- **Agentic Search**: Natural language query processing using LangChain.
- **Data Validation**: Duplicates, required fields, naming conventions
- **Replace Strategy**: Clear existing data, import fresh from Excel
- **Educational Implementation**: Extensive RDF concept explanations

---

## 🏗️ **ARCHITECTURE DESIGN**

### **RDF Data Model**
The data model is based on a hierarchy parsed from an Excel file:
```
DataDomain (top level)
├── SubDomain
    ├── Entity (data assets)
        ├── PhysicalTable (hanging off entities)
```

---

## 🔧 **COMPONENT STRUCTURE**

### **RDF Engine Modules**
```
api/
├── __init__.py
├── main.py                 # FastAPI endpoints
├── state_manager.py        # In-memory graph state
├── agentic_search.py       # NEW: LangChain agent for queries
└── rdf_engine/
    ├── __init__.py
    ├── triple_store.py     # Core RDF CRUD operations
    ├── excel_import.py     # Excel-to-RDF pipeline
```

### **Configuration Updates**
```
api/config/
├── 10_project_config.yaml   # Existing
├── 15_excel_import.yaml     # Import pipeline config
├── 20_logging.yaml          # Existing
└── config_manager.py        # Handles all config files
```

---

## 🤖 **AGENTIC SEARCH DESIGN**

### **New Component: `api/agentic_search.py`**
- **Purpose**: Provides a `MetadataAgent` class that can answer natural language questions about the RDF graph.
- **Framework**: Uses `LangChain` and `langgraph` to create a stateful agent.
- **LLM**: Connects to an OpenAI model (`ChatOpenAI`).
- **Process Flow**:
    1. Receives a user's natural language `prompt`.
    2. Receives a `schema_summary` of the current RDF graph from the `TripleStore`.
    3. Combines the prompt and schema into a detailed system message, instructing the LLM to act as an RDF expert.
    4. Invokes the LLM and returns the generated natural language response.
- **API Endpoint**: Exposed via the `/agent-query` endpoint in `api/main.py`.

---

## 📊 **EXCEL IMPORT PIPELINE DESIGN**

### **Configurable Column Mapping**
The entire import process is driven by `api/config/15_excel_import.yaml`. This allows the pipeline to adapt to different Excel file structures without code changes.

### **Import Process Flow**
1. **Read Excel File** - Using pandas/openpyxl
2. **Validate Structure** - Check required columns exist based on config
3. **Parse Hierarchy** - Build domain → subdomain → entity → table relationships
4. **Validate Data** - Check naming, duplicates, required fields based on config
5. **Backup Current** - Save existing RDF data
6. **Clear & Import** - Replace existing graph with new data
7. **Save to Turtle** - Persist the new graph in `data/imported_graph.ttl`

---

## 🎓 **EDUCATIONAL IMPLEMENTATION APPROACH**

### **🔑 CONFIG-DRIVEN DESIGN PRINCIPLE**
**CRITICAL REQUIREMENT**: ALL Excel processing is configuration-driven. There are no hardcoded column names, entity types, or business logic in the Python code.

### **RDF Concept Integration**
Each module teaches RDF concepts while implementing functionality:
- **triple_store.py**: RDF triples, subject-predicate-object model, schema summaries.
- **excel_import.py**: Mapping tabular data to an RDF graph structure.
- **agentic_search.py**: Using an LLM to reason about an RDF schema.

---

## ✅ **SUCCESS CRITERIA**

### **Functional Requirements**
- [✅] Load Excel file with configurable column mappings
- [✅] Parse domain → subdomain → entity → table hierarchy
- [✅] Validate data according to configurable rules
- [✅] Generate valid RDF triples in Turtle format
- [✅] Replace existing RDF data with imported data
- [✅] Answer natural language questions about the graph schema.

### **Educational Requirements**
- [✅] Extensive comments explaining RDF concepts
- [✅] Sample Excel files with business metadata examples
- [✅] Error messages that teach RDF best practices

### **Integration Requirements**
- [✅] Configuration system integration for all settings
- [✅] Logging integration with component-specific loggers
- [✅] Error handling with graceful failures
- [✅] Ready for GUI integration.
