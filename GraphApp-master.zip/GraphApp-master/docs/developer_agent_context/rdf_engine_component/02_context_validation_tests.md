# RDF Engine Component - Context Validation Tests

## 🎯 **UNDERSTANDING VERIFICATION**

Before implementing the RDF Engine, validate your understanding of key concepts by answering these questions. This ensures solid foundation knowledge before coding begins.

---

## 📚 **RDF FUNDAMENTALS**

### **Question 1: RDF Triple Structure**
**Scenario**: You have an Excel row: `Sales | Transactions | Sales Header | SALES_HDR`

**Question**: What RDF triples would represent this hierarchy?
**Hint**: Think subject-predicate-object for each relationship

<details>
<summary>Expected Answer Pattern</summary>

```turtle
# Domain contains SubDomain
meta:SalesDomain meta:contains meta:SalesTransactions .

# SubDomain includes Entity  
meta:SalesTransactions meta:includes meta:SalesHeader .

# Table implements Entity
meta:SALES_HDR meta:implements meta:SalesHeader .

# Type declarations
meta:SalesDomain a meta:DataDomain .
meta:SalesTransactions a meta:SubDomain .
meta:SalesHeader a meta:Entity .
meta:SALES_HDR a meta:PhysicalTable .
```
</details>

### **Question 2: Namespace Purpose**
**Question**: Why do we use `meta:SalesDomain` instead of just `SalesDomain`?
**Hint**: Think about uniqueness and conflicts

<details>
<summary>Expected Answer</summary>

- **Global uniqueness**: Prevents naming conflicts with other systems
- **Namespace organization**: Groups related concepts together
- **URI expansion**: `meta:SalesDomain` expands to `http://metadata.example.org/SalesDomain`
- **RDF standard compliance**: Follows W3C best practices
</details>

---

## 🔧 **EXCEL IMPORT PIPELINE**

### **Question 3: Configuration Flexibility**
**Given this Excel structure**:
```
| Business Area | Category | Data Asset | Database Table |
|---------------|----------|------------|----------------|
| Finance       | Reports  | P&L Data   | PROFIT_LOSS    |
```

**Question**: How would you configure the column mappings for this Excel file?
**Hint**: Look at the config structure in `15_excel_import.yaml`

<details>
<summary>Expected Answer</summary>

```yaml
column_mappings:
  domain_column: "Business Area"
  subdomain_column: "Category"
  entity_column: "Data Asset"
  table_column: "Database Table"
```
</details>

### **Question 4: Validation Strategy**
**Question**: What validation checks should happen before importing Excel data to RDF?
**Hint**: Think about data quality and RDF consistency

<details>
<summary>Expected Answer Categories</summary>

- **Structure validation**: Required columns exist
- **Data validation**: Non-empty required fields, naming conventions
- **Duplicate detection**: Same entities/tables not repeated
- **Relationship validation**: Parent-child hierarchy consistency
- **RDF validation**: Valid URI generation, namespace compliance
</details>

---

## 🗃️ **DATA MODELING**

### **Question 5: Hierarchical Relationships**
**Question**: In our business metadata model, what's the relationship chain from Domain to Physical Table?
**Hint**: Think about the organizational hierarchy

<details>
<summary>Expected Answer</summary>

```
DataDomain → SubDomain → Entity → PhysicalTable

With relationships:
- DataDomain "contains" SubDomain
- SubDomain "includes" Entity  
- PhysicalTable "implements" Entity
```
</details>

### **Question 6: SPARQL Query Logic**
**Question**: Write a SPARQL query to find all Physical Tables that belong to the "Sales" domain.
**Hint**: Follow the relationship chain

<details>
<summary>Expected Answer Pattern</summary>

```sparql
SELECT ?table WHERE {
  ?domain rdfs:label "Sales" .
  ?domain meta:contains ?subdomain .
  ?subdomain meta:includes ?entity .
  ?table meta:implements ?entity .
}
```
</details>

---

## 🏗️ **ARCHITECTURE INTEGRATION**

### **Question 7: Configuration Usage**
**Question**: How do you access the Excel import configuration in your Python code?
**Hint**: Use the established configuration pattern

<details>
<summary>Expected Answer</summary>

```python
from config import get_project_config

config = get_project_config()
import_config = config.excel_import
column_mappings = import_config.column_mappings.domain_column
validation_rules = import_config.validation_rules
```
</details>

### **Question 8: Logging Integration**
**Question**: How do you create a logger for the excel_import module?
**Hint**: Use the component logger pattern

<details>
<summary>Expected Answer</summary>

```python
from src.utils.logger_factory import get_component_logger

logger = get_component_logger('rdf_engine.excel_import')
logger.info("Starting Excel import process")
logger.debug("Processing row: {row}")
```
</details>

---

## 🔄 **MICRO-INCREMENTAL DEVELOPMENT**

### **Question 9: Development Sequence**
**Question**: What should be the first micro-increment when building the RDF Engine?
**Hint**: Think about the simplest possible RDF operation

<details>
<summary>Expected Answer</summary>

**Micro-Increment 1**: Create a single RDF triple
- Function: `create_triple(subject, predicate, object)`
- Use rdflib to create Graph instance
- Add one triple to the graph
- Test with simple example: `meta:TestEntity a meta:Entity`
</details>

### **Question 10: Testing Strategy**
**Question**: How would you test the Excel import functionality?
**Hint**: Think about sample data and validation

<details>
<summary>Expected Answer Categories</summary>

- **Unit tests**: Each function with sample Excel data
- **Sample files**: Create test Excel files with known structure
- **Validation tests**: Test all validation rules with invalid data
- **Integration tests**: Full pipeline from Excel to RDF queries
- **Edge cases**: Empty cells, special characters, duplicate data
</details>

---

## ✅ **READINESS CHECKLIST**

### **Conceptual Understanding**
- [ ] RDF triple structure (subject-predicate-object)
- [ ] Namespace purpose and URI expansion
- [ ] Hierarchical relationship modeling
- [ ] SPARQL basic query patterns

### **Technical Integration**
- [ ] Configuration system usage patterns
- [ ] Logging integration approach
- [ ] Micro-incremental development methodology
- [ ] Testing strategy for RDF operations

### **Business Context**
- [ ] Domain → SubDomain → Entity → Table hierarchy
- [ ] Excel column mapping flexibility
- [ ] Data validation requirements
- [ ] Replace import strategy implications

### **Implementation Readiness**
- [ ] Python rdflib library familiarity
- [ ] pandas Excel reading capabilities
- [ ] Error handling for file operations
- [ ] RDF serialization (Turtle format)

---

## 🎓 **LEARNING RESOURCES**

### **If You Need More Background**
- **RDF Primer**: https://www.w3.org/TR/rdf11-primer/
- **Turtle Syntax**: https://www.w3.org/TR/turtle/
- **SPARQL Tutorial**: https://www.w3.org/TR/sparql11-query/
- **rdflib Documentation**: https://rdflib.readthedocs.io/

### **Sample Excel Files**
Create test files matching these patterns for development:

**Simple Test File**:
```
| Data Domain | Sub Domain | Data Entity | Physical Table |
|-------------|------------|-------------|----------------|
| Sales       | Orders     | Order Header| ORDER_HDR      |
| Sales       | Orders     | Order Lines | ORDER_LINES    |
```

**Complex Test File** (for validation testing):
```
| Data Domain | Sub Domain | Data Entity      | Physical Table | Description    |
|-------------|------------|------------------|----------------|----------------|
| Finance     | Accounting | General Ledger   | GL_ACCOUNTS    | Chart of accounts |
| Finance     | Reporting  | P&L Statement    | PL_SUMMARY     | Profit & loss |
| HR          | Payroll    | Employee Master  | EMPLOYEES      | Staff records |
```

**Once you can answer these questions confidently, you're ready to begin RDF Engine implementation.**
