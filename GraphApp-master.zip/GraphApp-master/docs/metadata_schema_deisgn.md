```mermaid
classDiagram
    direction LR

    class GrowthPlatform {
        +label
        +description
    }

    class DataDomain {
        +label
        +description
    }

    class SubDomain {
        +label
        +description
    }

    class Entity {
        +label
        +description
    }

    class PhysicalTable {
        +label
        +description
    }

    class PhysicalColumn {
        +label
        +description
        +dataType
        +isNullable
    }



    class KPI {
        +label
        +description
        +calculationLogic
    }

    class Persona {
        +label
        +description
    }

    class ReportDashboard {
        +label: "Report / Dashboard"
        +description
        +sourceLink
    }

    GrowthPlatform "1" -- "N" DataDomain : aggregates
    DataDomain "1" -- "N" SubDomain : contains
    SubDomain "1" -- "N" Entity : includes
    
    Entity "1" -- "N" PhysicalTable : implementedBy
    Entity "N" -- "N" Entity : references

    PhysicalTable "1" -- "N" PhysicalColumn : hasColumn
    PhysicalColumn "N" -- "N" PhysicalColumn : hasForeignKey

    KPI "N" -- "N" Entity : measures
    KPI "N" -- "N" KPI : correlatesWith
    
    Persona "N" -- "N" Entity : analyzes
    Persona "N" -- "N" KPI : monitors
    Persona "N" -- "N" ReportDashboard : uses
    
    ReportDashboard "N" -- "N" Entity : consumes
    ReportDashboard "N" -- "N" KPI : visualizes
```