# Collaboration Patterns - RDF Metadata Graph

## 🎯 **USER COMMUNICATION PREFERENCES**

### **Key Behavior Instructions**
- **Slow Down**: Avoid making unagreed architecture assumptions.
- **Confirm Before Scripting**: Do not proceed with scripting until explicit approval is given.
- **One Step at a Time**: Go one step at a time and then prompt for confirmation.
- **Text Block Formatting**: Format prompts and responses as text blocks.

### **Response Patterns**
- **Succinct answers** until elaboration requested
- **Real-world examples and analogies** when explaining RDF/SPARQL concepts
- **Ask before generating output** - no assumptions about user needs
- **Question when ambiguous** - better to clarify than guess wrong

### **"Iterate" Command Protocol**
**Definition**: Take prompt + response → self-critique → improve → return only improved answer  
**Process**: Iterate minimum 3 times before presenting final result  
**Application**: Use for complex RDF modeling or SPARQL query design

### **Working Style Preferences**
- **Efficiency-focused** - minimize redundant work
- **Educational approach** - RDF/SPARQL learning integrated throughout
- **Simple to complex evolution** - start basic, add complexity iteratively
- **Modern GUI standards** - visually appealing with interactive features

---

## 🧠 **AGENT OPERATIONAL MEMORIES & BEHAVIORS**

### **Core Instructions**
- **Permission to Act**: ALWAYS ask for permission and opinion before taking any action, such as writing code, running commands, or modifying files. Present a plan or a proposed next step and wait for explicit approval (e.g., 'yes', 'proceed', 'ok') before executing.
- **Preserve Existing Code**: Do not arbitrarily remove or delete code in files that are being updated. Always review the file to be changed, understand its full context, and then pinpoint and modify only the necessary sections.

### **Technical Implementation Patterns**
- **Generic JSON Transformation**: The JSON transformation logic in `api/state_manager.py` must be generic to handle any relationship between nodes, not just a specific predicate like `contains`.
- **One-to-Many Relationships**: All relationships should be treated as potentially one-to-many and consistently represented as arrays in the JSON output to be handled correctly by the frontend.
- **Business Entity Node Creation**: The backend's JSON transformation logic should only create nodes for true business entities, which are defined as the subjects of triples in the business graph (`imported_graph.ttl`). URIs that are only used in the object position of an `rdf:type` predicate (e.g., `meta:DataDomain`) should not be created as separate nodes.

### **Environment and Tool Usage**
- **Terminal Commands**: The user prefers to run all terminal commands themselves. Provide the command and instructions, but never run the command directly unless explicitly asked.
- **Virtual Environment**: Use the existing virtual environment at the root of the project. Do not create new ones. Update dependencies via `requirements.txt`.
- **API Server Script**: The project includes a PowerShell script named `run_api.ps1` in the root directory to run the API server.

---

## 🔧 **TECHNICAL COMMUNICATION PATTERNS**

### **Infrastructure Preferences**
- **Proven patterns** - use established config/logging infrastructure
- **Component-based organization** - dedicated modules with clear interfaces
- **Educational code** - extensive comments explaining RDF concepts
- **Micro-incremental building** - validate each small piece
- **Virtual Environment**: Use the existing virtual environment at the root of the project. Do not create new ones. Update dependencies via `requirements.txt`.

### **File Operation Preferences**
- **Targeted updates** - use edit_file for specific sections
- **Context preservation** - maintain existing working code
- **Documentation integration** - update specs with implementation
- **Infrastructure-first** - complete setup before component development

### **Development Philosophy**
- **RDF standards compliance** - follow W3C specifications
- **Modern GUI patterns** - Next.js with contemporary styling
- **Educational value** - learn while building practical application
- **Iterative complexity** - start simple, evolve sophistication
- **🔑 CONFIG-DRIVEN APPROACH** - NEVER hardcode column names, entity types, or business logic
  - ALL Excel processing adapts to config changes
  - Logging messages use dynamic column/entity references from config
  - Validation rules driven by configuration
  - Entity hierarchy and relationships configurable
  - Code survives Excel structure changes without modification

---

## 📋 **PROJECT-SPECIFIC PATTERNS**

### **RDF Metadata Context**
- **Business entities** - transaction headers/details, master data
- **Agent automation** - metadata to help AI systems understand data
- **Graph relationships** - header-detail, master-reference, hierarchies
- **Performance focus** - support practical business metadata volumes

### **GUI Requirements**
- **Interactive visualization** - drag, zoom, pan graph canvas
- **Hover tooltips** - show RDF properties on mouseover
- **In-place editing** - click to modify node/edge attributes
- **Modern aesthetics** - contemporary styling with smooth animations

### **SPARQL Integration**
- **Query interface** - text input with syntax highlighting
- **Educational examples** - progressive complexity with explanations
- **Results visualization** - integrate query results with graph display
- **Learning support** - query builder assistance for beginners

---

## 🚀 **DEVELOPMENT WORKFLOW PATTERNS**

### **Component Development**
- **Infrastructure first** - config/logging before functionality
- **RDF engine foundation** - triple store before GUI
- **Micro-increments** - single function implementation and testing
- **Educational integration** - explain RDF concepts during implementation

### **Quality Standards**
- **RDF validation** - ensure triple consistency
- **SPARQL compliance** - follow standard query syntax
- **GUI responsiveness** - smooth interactions with large graphs
- **Code education** - comments that teach RDF/SPARQL concepts
- **Configuration adaptability** - code adapts to Excel/data structure changes via config
- **Dynamic processing** - no hardcoded assumptions about data schema

### **Testing Approach**
- **RDF data integrity** - validate triple store operations
- **SPARQL query correctness** - test standard query patterns
- **GUI interaction testing** - verify tooltip and editing functionality
- **Performance validation** - ensure reasonable response times

---

## 🎓 **LEARNING OPTIMIZATION PATTERNS**

### **RDF Concept Progression**
1. **Basic triples** - subject, predicate, object
2. **Namespace usage** - prefixes and URI management
3. **Class hierarchies** - rdfs:Class and rdf:type relationships
4. **Property definitions** - domain and range specifications
5. **Complex relationships** - transitive and hierarchical properties

### **SPARQL Query Progression**
1. **Simple SELECT** - basic pattern matching
2. **Filtered queries** - WHERE with conditions
3. **Multiple patterns** - joins and complex matching
4. **Property paths** - hierarchical relationship queries
5. **Aggregation** - COUNT, GROUP BY, statistical queries

### **Business Metadata Understanding**
1. **Entity identification** - what constitutes a business entity
2. **Relationship modeling** - header-detail, reference patterns
3. **Domain organization** - logical business area groupings
4. **Performance measurement** - KPI-to-entity connections
5. **User perspectives** - persona-based access patterns

---

## 💡 **SUCCESS FACTORS**

### **Communication Efficiency**
- Clear RDF/SPARQL concept explanations with business examples
- Progressive complexity without overwhelming detail
- Visual reinforcement of abstract RDF concepts
- Practical application of theoretical knowledge

### **Technical Delivery**
- Working RDF triple store with educational implementation
- Interactive GUI that demonstrates graph concepts visually
- SPARQL integration that supports learning progression
- Modern interface that engages and maintains interest

### **Educational Value**
- RDF standards compliance with learning explanations
- SPARQL query examples that build practical skills
- Business metadata context that shows real-world application
- Progressive complexity that builds confidence

**These collaboration patterns optimize for RDF/SPARQL learning while building practical business metadata management capabilities.**
