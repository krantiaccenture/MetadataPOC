# RDF Metadata Graph - System Architecture

## 🎯 **Project Overview**
**Purpose**: Educational RDF/SPARQL learning application for business metadata management  
**Focus**: Business transaction and master data entity relationships  
**Approach**: Modern client-server architecture, interactive web GUI, iterative complexity evolution  

## 🏗️ **System Architecture**

### **Core Components**
```mermaid
graph TD
    subgraph "Browser"
        A["Next.js Frontend"]
    end

    subgraph "Server"
        B["FastAPI Backend"]
        C["Triple Store (rdflib)"]
        D["Data Source (Excel/TTL)"]
        E["Agentic Search (LangChain)"]
    end

    A -- "HTTP API Calls" --> B
    B -- "Serves Graph & Agent Responses" --> A
    B -- "Loads/Queries Data" --> C
    B -- "Processes Queries" --> E
    C -- "Imports/Caches Data From" --> D

    style A fill:#D6EAF8,stroke:#3498DB
    style B fill:#D5F5E3,stroke:#2ECC71
    style E fill:#F9E79F,stroke:#F1C40F
```

### **Technology Stack**
- **RDF Library**: `rdflib` - Python standard for RDF/SPARQL
- **Backend Framework**: `FastAPI` - Modern, high-performance web framework for Python.
- **Frontend Framework**: `Next.js` - React framework for building server-side rendered and static web applications.
- **Graph Visualization**: `react-force-graph-2d` - Library for rendering interactive 2D graphs.
- **AI Agent Framework**: `LangChain` - For building applications with large language models.
- **Data Format**: Turtle (.ttl) - Human-readable RDF serialization
- **Query Engine**: rdflib's built-in SPARQL 1.1 processor

## 🔧 **RDF Data Model Design**

### **Namespace Definitions**
```turtle
@prefix meta: <http://metadata.example.org/> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
@prefix dcterms: <http://purl.org/dc/terms/> .
```

### **Node Types (RDF Classes)**
- **meta:DataDomain**: Business areas (Sales, Finance, etc.)
- **meta:SubDomain**: Sub-categories within domains.
- **meta:Entity**: Data assets/entities (Sales Transaction Header, Item Master)
- **meta:PhysicalTable**: Database tables implementing entities
- **meta:KPI**: Key Performance Indicators
- **meta:Persona**: User archetypes for analysis

### **Edge Types (RDF Properties)**
- **meta:contains**: `DataDomain` contains `SubDomain` or `Entity`.
- **meta:includes**: `SubDomain` includes `Entity`.
- **meta:implements**: `PhysicalTable` implements `Entity`.
- **meta:has_detail**: Connects header and detail transaction entities.
- **meta:references**: Connects transaction entities to master data.
- **meta:part_of_hierarchy**: For hierarchical master data.
- **meta:measures**: Connects a `KPI` to an `Entity`.
- **meta:analyzes**: Connects a `Persona` to an `Entity`.

## 🖥️ **GUI Architecture (Next.js)**

### **Main Window Components**
1. **Graph Canvas** (Central)
   - Interactive node/edge visualization using `react-force-graph-2d`.
   - Supports node selection, with future support for drag, zoom, and pan.
   - Renders data from a central Zustand store.

2. **Properties Panel** (Right)
   - Displays attributes of the selected node.
   - Subscribes to the `selectedNode` state in the Zustand store.

3. **Filter Panel** (Left)
   - Allows users to filter the graph view by node type.
   - Updates the `filters` state in the Zustand store, which triggers a re-computation of the visible graph.

4. **Metadata Agent Panel** (Left)
   - Provides a natural language query interface.
   - Sends user prompts to the backend agent and displays the response.

### **State Management**
- **Zustand**: A small, fast, and scalable state-management solution for React.
- **Single Store**: A single store (`useGraphStore`) holds the entire application state.

## 📁 **Project Structure**
```
Graphs/
├── backend/              # FastAPI Backend
│   ├── main.py           # API Endpoints
│   ├── core/
│   │   └── state_manager.py
│   ├── agents/
│   │   └── agentic_search.py
│   └── rdf_engine/
│       └── ...
├── frontend/             # Next.js Frontend
│   ├── src/
│   │   ├── app/
│   │   ├── components/
│   │   └── lib/
│   └── package.json
├── data/
├── docs/
└── requirements.txt
```

## 🚀 **Development Phases**

### **Phase 1: Core RDF Foundation** (✅ COMPLETED)
- RDF Triple Store and Excel Import pipeline in Python.

### **Phase 2: Web Migration & Visualization** (✅ COMPLETED)
- FastAPI backend to serve graph data.
- Next.js frontend with `react-force-graph-2d`.

### **Phase 3: Interactive Filtering & Querying** (✅ COMPLETED)
- Filter panel, Metadata Agent panel.

### **Phase 4: Advanced Interactivity & Editing** (IN PROGRESS)
- Full graph interactivity (pan, zoom, drag).
- Query result highlighting on the graph.
- In-place editing of node attributes.
